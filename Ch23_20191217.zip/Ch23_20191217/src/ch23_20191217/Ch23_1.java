/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch23_20191217;
import java.time.LocalTime;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
public class Ch23_1 {


    public static void main(String[] args) {
      Item i1 = new Item("A",10);
      System.out.println(i1);
      File file = new File("C:\\MyDir\\item.obj");
     
      try(FileOutputStream fout = new FileOutputStream(file);
          ObjectOutputStream oout = new   ObjectOutputStream(fout)  ){
          oout.writeObject(i1);
      }catch(Exception ex){
          System.out.println(ex);
      }
      
    }
    
}
