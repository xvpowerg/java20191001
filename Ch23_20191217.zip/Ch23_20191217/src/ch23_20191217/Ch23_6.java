/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch23_20191217;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.IOException;
import java.nio.file.StandardCopyOption;
/**
 *
 * @author xvpow
 */
public class Ch23_6 {
    public static void main(String[] args) {
       
//        Path p1 =  Paths.get("C:", "MyDir","Dir1","test.zip");
//        Path p2 =  Paths.get("C:", "MyDir","Dir1","test_copy.zip");
//       try{
//          Files.copy(p1, p2,StandardCopyOption.REPLACE_EXISTING);
//       }catch(IOException ex){
//          System.out.println(ex);
//       }

        Path p3 =  Paths.get("C:", "MyDir","Dir1","test.zip");
        Path p4 =  Paths.get("C:","MyDir","Dir2","test_move.zip");
       try{
          Files.move(p3, p4,StandardCopyOption.REPLACE_EXISTING,
                  StandardCopyOption.COPY_ATTRIBUTES);
       }catch(IOException ex){
          System.out.println(ex);
       }
        
    }
    
}
