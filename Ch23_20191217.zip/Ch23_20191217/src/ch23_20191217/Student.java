/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch23_20191217;
import java.io.Serializable;
public class Student extends Person implements Serializable {
    private String name;
    private int id;
    private Address addrObj;
    public Student(String name,int id,int height,int weight,
            String zipCode,String addr){
        super(height,weight);
        this.name = name;
        this.id = id;
        this.addrObj = new Address(zipCode,addr);     
    }
    public String getName(){
        return name;
    }
    public int getId(){
        return id;
    }
    
    public String toString(){
        return this.getName()+":"+this.getId()+":"+super.toString()+":"+addrObj;
    }
}
