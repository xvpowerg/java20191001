/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch23_20191217;

import java.io.Serializable;


public class Address implements Serializable {
    private String zipCode;
    private String addr;
    
    public Address(String zipCode, String addr){
        this.zipCode = zipCode;
        this.addr = addr;
    }
    
    public String toString(){
        return zipCode+":"+addr;
    }
    
}
