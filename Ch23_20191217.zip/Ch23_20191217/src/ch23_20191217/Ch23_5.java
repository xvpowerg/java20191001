/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch23_20191217;
import java.nio.file.Paths;
import java.nio.file.Path;
public class Ch23_5 {

    public static void main(String[] args) {
      Path p1 = Paths.get("c:", "MyDir","Dir1");
      Path otherPath = Paths.get("c:", "libs");
        System.out.println(p1.toAbsolutePath());
         System.out.println(p1.relativize(otherPath));
         
     Path p2 = Paths.get("c:", "MyDir","Dir2","Dir2_2");
      System.out.println(p2.getNameCount());
      System.out.println(p2.getName(2));
      
   Path p3 = Paths.get("d","MyDir", "MyDir1","innerDir1_1","Dir2_file_1.txt");
      System.out.println(p3.getNameCount());
      System.out.println(p3.getName(3));
      
      Path p4 = Paths.get("./Dir2_2/.././../");
      System.out.println(p4);
      System.out.println(p4.normalize());  
      
     Path p5 = Paths.get("c:","a","b");
     Path p6 = Paths.get("value.txt");
     //融合目錄
     Path newPath =  p5.resolve(p6);
     System.out.println(newPath);
     //融合目錄 如果右邊的目錄是完整目錄那麼會取代原本目錄
      Path p7 = Paths.get("c:","a","b");
     Path p8 = Paths.get("d:","value.txt");
     Path newPath2 =  p7.resolve(p8);
     System.out.println(newPath2);
     
    Path p9 = Paths.get("c:", "a","b","c","d","e","f");
    Path p9Sub1 = p9.subpath(2, 4);
    System.out.println(p9Sub1);
     Path p9Sub2 = p9.subpath(1, 5);
     System.out.println(p9Sub2); 
     
     
      
    }
    
}
