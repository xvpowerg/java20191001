/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch23_20191217;
import java.time.LocalTime;
import java.io.Serializable;
import java.io.IOException;
public class Item implements Serializable  {
    private static final long serialVersionUID = 45L;
    private String name;
    private int weight;
    private int price;
    private transient LocalTime objCreateTime;
    
    public Item(String name,int price){
        this.name = name;
        this.price = price;
        objCreateTime = LocalTime.now();
    }
    
    public String toString(){
        return name+"-"+price+"-"+objCreateTime;
    }
    //參與序列化
    private void writeObject(java.io.ObjectOutputStream out)
            throws IOException {
        System.out.println("writeObject....");
        out.defaultWriteObject();
        out.writeInt(9713);
    }
    
    //參與反序列化
    private void readObject(java.io.ObjectInputStream in)
            throws IOException,ClassNotFoundException{
        System.out.println("readObject....");
        //已定義的序列化
        in.defaultReadObject();
        //客製自己要的反序列化
        objCreateTime = LocalTime.now();
       int v =  in.readInt();
       System.out.println("v:"+v);
    }
    
}
