/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch23_20191217;

import java.io.Serializable;

/**
 *
 * @author xvpow
 */
public class Person implements Serializable  {
    private int height;
    private int weight;
    public Person(int height,int weight){
        this.height = height;
        this.weight = weight;        
    }
    public String toString(){
        return this.height +"-"+this.weight;
    }
    
}
