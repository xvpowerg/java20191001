/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch23_20191217;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
/**
 *
 * @author xvpow
 */
public class Ch23_2 {


    public static void main(String[] args) {
          File file = new File("C:\\MyDir\\item.obj");   
        try(FileInputStream fIn = new FileInputStream(file);
           ObjectInputStream oIn = new   ObjectInputStream(fIn);   ){
           Item i = (Item) oIn.readObject();
           System.out.println(i);
        }catch(Exception ex){
            System.out.println(ex);
        }
        
        
    }
    
}
