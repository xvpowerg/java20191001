/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch23_20191217;
import java.util.HashMap;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
public class Ch23_3 {

    public static void main(String[] args) {
      HashMap<String,Student> map = 
              new HashMap<>();
      
        for (int i = 1; i<=10000;i++){
            Student st = 
            new Student("Ken"+i,i,172,51,
                      "ZipCode"+i,"Address"+i);
            map.put("Ken"+i, st); 
        }
        File file = new File("C:\\MyDir\\stmap.obj");
        try(FileOutputStream fout = new FileOutputStream(file);
            ObjectOutputStream oout = new  ObjectOutputStream(fout)   ){
            oout.writeObject(map);
        }catch(Exception ex){
            System.out.println(ex);
        }
        
           //name Ken+i
            //id i
            //height 172
            //weight 51
            // ZipCode+i   Address+i
            //幫我序列化一個? 可做到 我傳入一個 Ken2 回傳 Ken2這位學生得物件
             //Ken2 2  172 51 ZipCode2 Address2
        
        
        
    }
    
}
