/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch14_20191114;

/**
 *
 * @author xvpow
 */
public class Ch14_4 {
    enum Fruit{
        APPLE,
        BANANA,
        KIWI,
        CHARRY
    }
    
    public static void main(String[] args) {
    
        //列舉
        
        //Fruit 是一個列舉類
        //APPLE 是一個物件 這物件的類別是Fruit
       /* Fruit f1 = Fruit.APPLE;        
        System.out.println(f1);
        System.out.println(f1.ordinal());*/
       
//       Fruit f2 = Fruit.KIWI;
//        switch(f2){
//            case APPLE:
//               System.out.println("蘋果:20");
//                break;
//            case  BANANA:
//                System.out.println("香蕉:10");
//                break;
//            case   KIWI:
//                System.out.println("奇異果:15");
//                break;
//            case   CHARRY:
//                    System.out.println("櫻桃:5");
//                break;
//                
//        }
        //討論靜態方法
        //1
//       Fruit BANANA=  Fruit.valueOf("BANANA");
//       System.out.println(BANANA == Fruit.BANANA);
//       Fruit.valueOf("Fish");
//       
//       Fruit[] fvs = Fruit.values();
//       for (Fruit f1 :fvs){
//           System.out.println(f1);
//       }
       //列舉只有toString可複寫
       //其他類不可extends 列舉
       Fruit BANANA=  Fruit.valueOf("BANANA");
        int od= BANANA.ordinal();
        System.out.println(od);
        System.out.println( BANANA.name());
      
        //左邊比右邊大回傳正數
        //左邊比右邊小回傳負數
        //左右兩邊一樣回傳0
    System.out.println(BANANA.compareTo(BANANA));   
    System.out.println(Fruit.APPLE.compareTo(BANANA));   
    
    }
    
}
