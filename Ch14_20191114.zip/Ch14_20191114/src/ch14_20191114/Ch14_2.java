/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch14_20191114;
import java.util.function.Function;
import java.util.function.Consumer;
public class Ch14_2 {

    static void method(Function<String,Integer> f1,String... msg){
        for (String v : msg){
            f1.apply(v);
        }        
    }
    
    
    static void showItemComsumer(Item item){
        System.out.println(item.getName());
    }
    static void showItems(Consumer<Item> constmer,Item ...it){
            for (Item i :it){
                constmer.accept(i);
            }
    }
    
    
    static int strToChar(String st){
          int sum  =0;
           for (int i = 0;i <st.length();i++){
               sum += st.charAt(i);
           }
           System.out.printf("%s:%d%n",st,sum);
           return sum;
    }
    public static void main(String[] args) {
       
        String s1 = "ABC";
        method((st)->{
          int sum  =0;
         for (int i = 0;i <st.length();i++){
               sum += st.charAt(i);
           }
           System.out.printf("%s:%d%n",st,sum);
        return sum;
        },"ABC","EFG");
        
         method(
          Ch14_2::strToChar
        ,"ABC","EFG");
       // ABC:
       // EFG:
        //s1.charAt(0)
        //s1.length()
        
        
        showItems(Ch14_2::showItemComsumer,new Item("A"),new Item("F"));
    }
    
}
