/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch14_20191114;

public class Ch14_1 {

      static void runAction(int a,int b,Action action){
          if (a >b){
              action.doing("目前A大於B");
          }
      }
      
      static void sumCalcu(int a,int b,IntCalculation c){
         int sum =  c.calcu(a, b);
         System.out.println(sum);
      }
      
      static void showItem(String msg,TestItem ti){
          System.out.println(ti.generatorItem(msg));
      }
    public static void main(String[] args) {
     
        //匿名內部類
        runAction(15,2,new Action(){
            public void doing(String msg){
                System.out.println(msg);
            }
        });
        //lambda 
        //只能用在functionalinterface 
       runAction(15,2,
         (msg)->{
           System.out.println(msg);});
       
        runAction(15,2,
         msg->System.out.println(msg));
        
       sumCalcu(25,30,(v1,v2)->{       
       return v1 +v2;
       });
       
       
      sumCalcu(25,30,(v1,v2)-> v1 +v2);
      
      showItem("Test1",(msg)->new Item(msg));
      
      //method reference
        showItem("Test1",Item::new);
        
        
    }
    
}
