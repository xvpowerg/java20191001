/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch14_20191114;
import java.util.function.Predicate;
public class Ch14_3 {
     
    static void printPassScore(Predicate<Integer> p,int... scores){
        for (int s : scores){
            if (p.test(s)){
                System.out.println(s);
            }
        }
    }
    static boolean testPass(int v){
        return v >60;
    }
    public static void main(String[] args) {
       int[] values = {25,71,83,10,5,2,94};
       
       printPassScore((s)->s > 60,
                    values);
        printPassScore(Ch14_3::testPass,
                    values);
       
        
        
    }
    
}
