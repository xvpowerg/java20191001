/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch14_20191114;

/**
 *
 * @author xvpow
 */
public class Ch14_5 {
    enum Fruit{
        APPLE("蘋果"),
        BANANA("香蕉"),
        KIWI("奇異果"),
        CHARRY("櫻桃");
     private String type;
     private int calorie;
     //建構子一定要是私有
     private Fruit(String type){
         this.type = type;
     }
     public int getCalorie(){
         return calorie;
     }
     public void setCalorie(int calorie){
          this.calorie = calorie;
     }
     public String toString(){
         return type;
     }
    }
    
    public static void main(String[] args) {
        Fruit.BANANA.setCalorie(250);
        
       System.out.println(Fruit.BANANA.getCalorie());
    }
    
}
