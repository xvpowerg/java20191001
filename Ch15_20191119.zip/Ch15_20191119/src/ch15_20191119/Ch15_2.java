/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch15_20191119;
import java.util.ArrayList;
/**
 *
 * @author xvpow
 */
public class Ch15_2 {
      static int sum = 0;
    public static void main(String[] args) {
        //所有集合類都只能放置參考型別
        //List
           //ArrayList --  無限大
           //LinkedList
           ArrayList list = new ArrayList();
           list.add(20);
           list.add(30);
           list.add(10);
           list.add(6);
           list.add("AA");
           
//           for (int i =0;i <list.size();i++){
//               System.out.println(list.get(i));
//           }

//          for (Object obj : list){
//              System.out.println(obj);
//          }
 

        //lambda語法 與內部類 不可修改區域變數
          list.forEach((obj)->{
             // if (obj instanceof Integer){
                    sum += (Integer)obj;     
              //}                                   
          });
          System.out.println(sum);
           
        //Set
           //HashSet
             //LinkedHashSet
           //TreeSet        
           
        //Map
          //HashMap
            //LinkedHashMap
          //TreeMap
          
        
        
    }
    
}
