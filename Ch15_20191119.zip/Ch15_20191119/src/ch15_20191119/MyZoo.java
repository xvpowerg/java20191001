/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch15_20191119;

import ch15_20191119.animal.Animal;
import ch15_20191119.animal.Dog;
import ch15_20191119.animal.Cat;
import ch15_20191119.animal.Tiger;
import ch15_20191119.animal.Bear;
import ch15_20191119.animal.Elephant;
import ch15_20191119.animal.AnimalNotFindException;
/**
 *
 * @author xvpow
 */
public class MyZoo {
    public enum Animals{
        DOG(new Dog()),
        CAT(new Cat()),
        TIGER(new Tiger()),
        BEAR(new Bear()),
        ELEPHANT(new Elephant());
        private Animal animal;
        public Animal getAnimal(){
            return animal;
        }
        private Animals(Animal animal){
            this.animal = animal;
        }
    }
    
       public static Animal getAnimal(Animals animalType){
         return animalType.getAnimal(); 
       }
    
    
    //Dog
    //Cat
    //Tiger
    //Bear
    //Elephant
    //如果不是以上動物~拋出AnimalNotFindException例外
    public static final int DOG = 100;
    public static final int CAT = 101;
    public static final int TIGER = 102;
    public static final int BEAR = 103;
    public static final int ELEPHANT = 104;
    public static Animal getAnimal(int animalType){
        switch(animalType){
            case DOG:
                return new Dog();
            case  CAT:
                   return new Cat();
            case TIGER:
                 return new Tiger();
            case BEAR:
                return new Bear();
            case ELEPHANT:
               return new Elephant();
        }
       throw new AnimalNotFindException("找不到動物");
    }
}
