/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch15_20191119;

import ch15_20191119.animal.Animal;
import ch15_20191119.animal.Bear;
/**
 *
 * @author xvpow
 */
public class Ch15_1 {
    
    public static void main(String[] args) {

//        Animal a1 =  MyZoo.getAnimal(11111);
//        System.out.println(a1);
      Animal a2 =  MyZoo.getAnimal(MyZoo.CAT); 
         System.out.println(a2);
//        Bear bear1 = new Bear();
//         System.out.println(bear1);
    }
    
}
