/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch15_20191119;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import static ch15_20191119.Ch15_3.foreach;
/**
 *
 * @author xvpow
 */
public class Ch15_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       ArrayList<Integer> list = new ArrayList<>();    
      
           list.add(20);
           list.add(30);
           list.add(10);
           list.add(6);
           list.add(20);
           Integer[] arrayx = {1,2,9,6,7};
           
        List<Integer> myList =  Arrays.asList(arrayx);
        //myList.add(50);
            foreach(myList);
            
      Integer[] listToArray = list.toArray(new Integer[2]);
      System.out.println(listToArray[3]);
            
//           list.sort((v1,v2)->v1-v2);
//           foreach(list);
           
           
           
//           list.replaceAll((v)->v +10);
//           foreach(list);
           
//           list.removeIf((v)->v < 20);
//           foreach(list);
         
//        ArrayList<Integer> list2 = new ArrayList<>();        
//        list2.add(30);
//        list2.add(10);
//        list.removeAll(list2);
//        Ch15_3.foreach(list);
           
//           list.remove(Integer.valueOf(10));
//           Ch15_3.foreach(list);
           
//          Iterator<Integer> it =  list.iterator();
//          while(it.hasNext()){
//             
//              System.out.println(it.next());
//            it.remove();
//          }
    }
    
}
