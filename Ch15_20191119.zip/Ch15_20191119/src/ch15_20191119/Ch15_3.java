/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch15_20191119;

import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author xvpow
 */
public class Ch15_3 {

    /**
     * @param args the command line arguments
     */
    public static <T>void foreach(List<T> list){
        list.forEach(System.out::println);
        System.out.println("===================");
    }
    static int sum = 0;
    public static void main(String[] args) {
      ArrayList<Integer> list = new ArrayList<>();    
      
           list.add(20);
           list.add(30);
           list.add(10);
           list.add(6);
//       list.forEach((v)->{
//            sum += v;       
//       });
//     System.out.println(sum);

//    list.add(2, 21);
//    foreach(list);
    /*ArrayList<Integer>  list2 = new ArrayList<>();
    list2.add(150);
    list2.add(120);
    list2.add(126);
    list.addAll(list2);
    foreach(list);
    
    ArrayList<Integer>  list3 = new ArrayList<>();
    list3.add(210);
    list3.add(230);
    list.addAll(3, list3);
    foreach(list);*/
    int index = list.indexOf(10);
    System.out.println(index);
    int index2 = list.indexOf(95000);
    System.out.println(index2);
    
    }
    
}
