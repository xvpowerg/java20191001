/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c4_20191010;
public class Ch4_5 {

    public static void main(String[] args) {
      //多維陣列
       int[][] array2x3 = new int[2][3];       
      int[][][] array2x3x4 = new int[3][2][4];
      
      array2x3[0][0] = 10;
      array2x3[0][1] = 71;
     
      array2x3[1][1] = 89;
      array2x3[1][2] = 32;
      //取row 的長度
      for(int i =0;i <array2x3.length ;i++){
          //取Colum的長度
          for (int k =0 ;k < array2x3[i].length;k++){
              System.out.print(array2x3[i][k]+" ");
          }
          System.out.println();          
      }
      //=====================
      for (int[] array1 : array2x3){
          for (int v1 : array1){
              System.out.print(v1+" ");
          }
          System.out.println();
      }
      
      
        
    }
    
}
