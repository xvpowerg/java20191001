/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c4_20191010;
import java.util.Arrays;
public class Ch4_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[] array1 = {1,2,3,4,5,6,7};
        int[] newArray =  Arrays.copyOf(array1,array1.length);
        for (int v : newArray){
            System.out.print(v+" ");
        }
          System.out.println();
        int[] newArray2 =  Arrays.copyOfRange(array1, 2, 6);
          for (int v : newArray2){
            System.out.print(v+" ");
        }
           System.out.println("============== ");  
          String[] names = new String[100];
           // Arrays.fill(names, "");
          System.out.println(names[0].equals(""));
      
    }
    
}
