/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c4_20191010;

public class Ch4_7 {

    public static void main(String[] args) {
       int[][] array2xn = new int[2][];
       //不規則形
        array2xn[0] = new int[3];
        array2xn[1]=new int[2];
        
        array2xn[0][2] = 8;
        array2xn[0][1]= 31;
        array2xn[1][1]= 62;
        
        for (int[] array : array2xn ){
            for (int v : array){
                  System.out.print(v+" ");
            }
             System.out.println();
        }
        
      int[][] array3xn = new int[3][];   
        array3xn[1] = new int[2];
        array3xn[2] = new int[3];
        
        //array3xn[1][2] = 12;
        array3xn[2][0] = 71;
        array3xn[0][1] = 31;
        
        
    }
    
}


