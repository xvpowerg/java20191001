/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c4_20191010;

/**
 *
 * @author xvpow
 */
public class Ch4_9 {
    public static void main(String[] args) {
      //字串所有的方法都不會改變來源
     String msg = "ABCDEF";
     String value =  msg.toLowerCase();
     System.out.println(msg);
     System.out.println(value);  
        
        
    }
    
    public void t1(){
        throw new TestError();
    }
 
}
