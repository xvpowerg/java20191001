/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c4_20191010;
import java.util.Arrays;
public class Ch4_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      String[] arrayStr = {"g","D","E","b"};
       Arrays.sort(arrayStr);
      //D E b g
      int index = Arrays.binarySearch(arrayStr, "E");
      System.out.println(index);
      //小於所數值
      int index2 =Arrays.binarySearch(arrayStr, "Bzer");
      System.out.println(index2);
      //大於所數值
      int index3 = Arrays.binarySearch(arrayStr, "hello");
       System.out.println(index3);
      //之間
       int index4 = Arrays.binarySearch(arrayStr, "Irir"); 
       System.out.println(index4);
    }
    
}
