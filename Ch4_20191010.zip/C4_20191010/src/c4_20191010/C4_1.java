/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c4_20191010;
import java.util.Arrays;
public class C4_1 {
    public static void main(String[] args) {
        int[] array1 = {9,75,6,3,32};
        Arrays.sort(array1);
        //3 6 9 32 75
       int index =  Arrays.binarySearch(array1, 9);
       System.out.println(index);
       //找不到的情況
       //1 比所有都小 回傳 -1
        int index2 = Arrays.binarySearch(array1, 2);
        System.out.println(index2);
        int index3 =  Arrays.binarySearch(array1, 0);
         System.out.println(index3);
       //2 比所有都大 公式 (陣列元素長度 + 1) * -1
        int index4 = Arrays.binarySearch(array1, 92);
         System.out.println(index4);
          int index5 = Arrays.binarySearch(array1, 950);
         System.out.println(index5);
       //3 落在之間 找到比搜尋數值大一點的個數 * -1
        int index6 = Arrays.binarySearch(array1, 10);
         System.out.println(index6);
        int index7 = Arrays.binarySearch(array1, 52);
          System.out.println(index7);
    }
    
}
