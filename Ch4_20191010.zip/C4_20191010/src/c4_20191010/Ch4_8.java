/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c4_20191010;
import java.util.ArrayList;
public class Ch4_8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //無限長度的Array
       ArrayList list = new ArrayList();
       list.add("iPhone");
       list.add("Ipad");
       list.add("Switch");
       String s1 = "";
       System.out.println(s1.length());
       int[] array = new int[3];
       System.out.println(array.length);
       
//       for (int i = 0;i<list.size();i++){
//           System.out.println(list.get(i));
//       }        
       list.forEach(System.out::println);
       
        System.out.println("======remove=========");
       list.remove("Ipad");
      list.forEach(System.out::println);   
   System.out.println("======Insert=========");      
     list.add(1, "PS5");
     list.forEach(System.out::println);
     
     
    }
    
}
