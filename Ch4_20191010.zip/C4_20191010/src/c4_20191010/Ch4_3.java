/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c4_20191010;

/**
 *
 * @author xvpow
 */
public class Ch4_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[] array1 = {1,2,3,4,5,6,7};
        int[] array2;
        //小練習
        //1 我想copy array1 所有內容到 array2
        array2 = new int[array1.length];
        for (int i =0;i<array1.length;i++){
            array2[i] = array1[i];
        }
        for(int v1 : array2){
          //  System.out.print(v1+" ");
        }
        
          //2 我想copy array1 由index = 2 開始 到 index 5 數值到array2
        int start = 2;
        int end = 5;
        int length = end - start ;
        array2 = new int[length+1];
        for (int i = start,k=0;i <= end;i++,k++){       
            array2[ k ] = array1[i];
        }
        
        for (int v : array2){
            System.out.println(v);
        }
        
        
    }
    
}
