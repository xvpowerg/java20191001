/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c4_20191010;

public class Ch4_6 {

    public static void main(String[] args) {
        //多維陣列宣告方式
        //左邊[]數量相加等於右邊就對了!
      int[][] array2x3 = new int[2][3];
      int[] array3x2[] = new int[3][2];
      int array2x2[][]  =new int[2][2];
      
   int[][] array2x3_2 = {{1,5,2},
                         {6,7,8},
                         {9,3,4}};
   
  int[][][] array2x3x2 = {{{1,6},
                           {7,8},
                           {9,3}},
                          {{4,3} ,
                           {10,25},
                           {83,71}} };
     int[][] array3xn = new int[3][];
     int[][]array1x2 = new int[][]{ {2,5  }  };
        
     
     
     
    }
    
}
