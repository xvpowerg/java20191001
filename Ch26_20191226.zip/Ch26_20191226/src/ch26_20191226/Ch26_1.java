/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch26_20191226;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.SQLException;
/**
 *
 * @author xvpow
 */
public class Ch26_1 {
    public static void main(String[] args) {
        String url = "jdbc:derby://localhost:1527/test1db";
        String user = "qwer";
         String password = "qwer";
           Connection conn =   null;
           Statement st =null;
         try{
             java.util.Random ran = new  java.util.Random();//1~50000
             int id = ran.nextInt(50000);
               conn =   DriverManager.getConnection(url, user, password);
               st =  conn.createStatement();
              int count = 
                  st.executeUpdate("INSERT INTO Student(id,firstname,score) "
                          + "VALUES ("+id+",'Gigi',78)");
              if (count > 0){
                  System.out.println("新增成功!");
              }else{
                  System.out.println("新增失敗!");
              }
         }catch(SQLException ex){
             System.out.println(ex);
         }finally{
             try{st.close();
                 conn.close();}catch(Exception ex){}
         }
     
        
        
        
    }
    
}
