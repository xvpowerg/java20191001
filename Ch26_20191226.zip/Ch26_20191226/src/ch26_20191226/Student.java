/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch26_20191226;

/**
 *
 * @author xvpow
 */
public class Student {
    private int id;
    private String firstName;
    private int score;
    
    public Student(int id,String firstName, int score){
        this.id = id;
        this.firstName = firstName;
        this.score = score;
    }
    
    public String toString(){
        return id+":"+this.firstName+":"+this.score;
    }
    
}
