/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch26_20191226;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author xvpow
 */
public class Ch26_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      String url = "jdbc:derby://localhost:1527/test1db";
        String user = "qwer";
         String password = "qwer";
           Connection conn =   null;
           Statement st =null;
         try{
             java.util.Random ran = new  java.util.Random();//1~50000
            
               conn =   DriverManager.getConnection(url, user, password);
               st =  conn.createStatement();
               conn.setAutoCommit(false);
               for (int i =1;i<=3;i++){
                    int id = ran.nextInt(50000);
                   if (i==3) throw new SQLException("Error!!");
                   int count = 
                  st.executeUpdate("INSERT INTO Student(id,firstname,score) "
                                + "VALUES ("+id+",'2Test"+id+"',78)");
                    if (count > 0){
                        System.out.println("新增成功!");
                    }else{
                        System.out.println("新增失敗!");
                    }
               }
            conn.commit();
         }catch(SQLException ex){
             System.out.println(ex);
         }finally{
             try{st.close();
                 conn.close();}catch(Exception ex){}
         }
    }
    
}
