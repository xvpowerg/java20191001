/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20191024;
import java.util.Scanner;
/**
 *
 * @author xvpow
 */
public class Ch8_2 {

     static Animal getAnimal(int type){
         switch(type){
             case 1:
                 return new Dog("BoBo",1,2,1.5f);
             case 2:
                 return new Cat("Nina",3,6,10);
         }
         return null;
     }
    public static void main(String[] args) {
        //
        Scanner scn = new Scanner(System.in);
        String type = scn.next();
        Animal animal = getAnimal(Integer.parseInt(type));
        animal.print();
    }
    //有一個類別Person
      // 屬性有:1 String name  2 int salary  3 int year
      // 建構子 :可寫入以上屬性
      // getTotalSalary() 回傳 salary
      //print() 顯示 所有屬性
    //有兩個子類  Employee Manager     
    // Employee
      //getTotalSalary() 回傳 salary + 100
    //print() 顯示 所有屬性 並加上員工
    //Manager 
    //getTotalSalary() 回傳 salary + 500
    //print() 顯示 所有屬性 並加上管理人員
}
