/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20191024;

/**
 *
 * @author xvpow
 */
public class Cat  extends Animal{
    
    Cat(){
        
    }
   Cat(String name,int age,float height,float weight){
       super(name,age,height,weight);
   }
   
  void print(){
      System.out.print("Cat:");
      super.print();
  }
}
