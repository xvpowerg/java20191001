/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20191024;


//extends 繼承
//可吧Animal部分能力延伸到Dog
//Dog可繼承的能力有
//以下不包含建構子
//1 public,protected 的所有內容 
//2 在相同package 預設的所有內容

public class Dog extends Animal{
   Dog(){}
   
   Dog(String name,int age,
           float height,float weight){
       //super()會呼叫父類建構子
       //super() 必須是建構子的第一條命令           
       super(name,age,height,weight);
//       this.setName(name);
//       this.setAge(age);
//       this.setHeight(height);
//       this.setWeight(weight);
   }
   //複寫 Override
  void print(){
      System.out.print("Dog:");
      //呼叫父類別的方法
      super.print();      
  }
}
