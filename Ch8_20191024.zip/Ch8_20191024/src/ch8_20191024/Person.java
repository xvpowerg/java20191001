/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20191024;

/**
 *
 * @author xvpow
 */
public class Person {
     private String name;
     private int salary;
     private int year;
     Person(){
     }
     
     Person(String name,int salary,int year){
         this.name = name;
         this.salary = salary;
         this.year = year;
     }
     
     public void setName(String name){
        this.name = name; 
     }
     public String getName(){
        return this.name; 
     }  
     
     public void setSalary(int salary){
        this.salary = salary; 
     }
     public int getSalary(){
        return this.salary; 
     }     
     public void setYear(int year){
        this.year = year; 
     }
     public int getYear(){
        return this.year; 
     }  
     public int getTotalSalary(){
         return this.getSalary();
     }
     
    void print(){
        System.out.println(this.getName()+":"+this.getYear()+":"+this.getTotalSalary());
    }
}
