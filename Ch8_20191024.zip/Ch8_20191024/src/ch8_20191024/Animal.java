/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20191024;

/**
 *
 * @author xvpow
 */
public class Animal {
    private String name;   
    private int age;
    private float height;
    private float weight;
    Animal(){
        
    }
   Animal(String name,int age,float height,float weight){
        this.name = name;
        this.age = age;
        this.height = height;
        this.weight = weight;
    }
    
   public String getName(){
       return name;
   }
   public void setName(String name){
       this.name = name;
   }
   
   public int getAge(){
       return age;
   }
   
   public void setAge(int age){
       this.age = age;
   }
   
   public float getHeight(){
       return this.height;
   }
   
   public void setHeight(float height){
       this.height = height;
   }
   
      public float getWeight(){
       return this.weight;
   }
   
   public void setWeight(float weight){
       this.weight = weight;
   }
   
   void print(){
       System.out.println(this.getName()+":"+this.getAge()+":"+
                         this.getHeight()+":"+this.getWeight());
   }
   
}
