/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20191024;
public class Ch8_1 {
//     static void printAnimal(Dog dog){
//         dog.print();
//     }
//     
//     static void printAnimal(Cat cat){
//         cat.print();
//     }
    //多形
     static void printAnimal(Animal animal){
         animal.print();
     }
    public static void main(String[] args) {
       Animal animal = new Animal("LuLu",5,15,10);
       animal.print();
          
       Dog dog1 = new Dog();
       dog1.setName("Nana");
       dog1.setAge(6);
       dog1.setHeight(10);
       dog1.setWeight(5);
       dog1.print();
       
       Dog dog2 = new Dog("Irirs",2,3,1); 
       dog2.print();
       
       Cat cat1 = new Cat("Kitty",10,20,30);
       cat1.print();
       
        printAnimal(dog2);
        printAnimal(cat1);
        
       Animal a1 = dog2; 
    }
    
}
