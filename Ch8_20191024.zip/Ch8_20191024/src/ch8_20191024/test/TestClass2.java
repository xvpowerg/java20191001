/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20191024.test;
import ch8_20191024.TestClass;
/**
 *
 * @author xvpow
 */
public class TestClass2  extends TestClass{
    public void testValue(){
        //因為TestClass2 extends TestClass 所以可以讀到protectedValue
        this.protectedValue = "Pro";
        this.publicValue = "PPP";
    }
}
