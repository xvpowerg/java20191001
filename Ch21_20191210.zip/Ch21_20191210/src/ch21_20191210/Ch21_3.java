/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch21_20191210;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 *
 * @author xvpow
 */
public class Ch21_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         Employee emp1 = new Employee("Ken",52000);
       Employee emp2 = new Employee("Lindy",32000);
      Employee emp3 = new Employee("Tom",92000);
      Employee emp4 = new Employee("Jack",72000);
      Employee emp5 = new Employee("Ruby",72000);
      Employee emp6 = new Employee("Iris",32000);
      ArrayList<Employee> listEmp = new ArrayList<>();
      listEmp.add(emp1);
      listEmp.add(emp2);
      listEmp.add(emp3);
      listEmp.add(emp4);
      listEmp.add(emp5);
      listEmp.add(emp6);
      
//    Map<Integer,List<Employee>> groupMap 
//            =listEmp.stream().collect(Collectors.groupingBy(emp->(emp.getSalary()/10000) 
//                                                          * 10000 ));
//   List<Employee> g1List =  groupMap.get(30000);
//   g1List.stream().forEach(System.out::println);

//Map<Integer,List<Integer>> obj = listEmp.stream().
//                collect(Collectors.groupingBy(emp->(emp.getSalary()/10000) 
//                                                          * 10000,
//                         Collectors.mapping(emp->emp.getName().length() ,
//                                 Collectors.toList()) ));
//System.out.println(obj);
//Map<Boolean,List<Employee>> map =  listEmp.stream().
//        collect(Collectors.partitioningBy((emp->emp.getSalary() > 40000)));
//System.out.println(map);
     String values =  listEmp.stream().map(emp->emp.getName()).
              collect(Collectors.joining(",", "Names:", "."));
    System.out.println(values);
    
    
    
    }
    
}
