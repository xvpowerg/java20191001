/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch21_20191210;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.io.FileNotFoundException;

public class Ch21_6 {

    public static void main(String[] args) {
           File srcFile = new File("c:\\MyDir\\test.zip");
           File targetFile = new File("c:\\MyDir\\test_copy.zip");
           
           try{
              InputStream fin = new BufferedInputStream(new FileInputStream(srcFile)) ;
              OutputStream fOut = new BufferedOutputStream(new FileOutputStream(targetFile));
              System.out.println("開始......");
                int data = -1;
                while( (data = fin.read()) != -1){
                    fOut.write(data);
                }
                System.out.println("完成......");
                
                fOut.close();
                fin.close();
           }catch(FileNotFoundException ex){
               System.out.println(ex);
           }catch(IOException ex){
               System.out.println(ex);
           }
           
           
    }
    
}
