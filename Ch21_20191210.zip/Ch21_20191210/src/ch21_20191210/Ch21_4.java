/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch21_20191210;

import java.util.IntSummaryStatistics;
import java.util.stream.IntStream;

/**
 *
 * @author xvpow
 */
public class Ch21_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        IntSummaryStatistics is=   IntStream.of(5,6,8,9,1).summaryStatistics();
        System.out.println(is.getSum());
    }
    
}
