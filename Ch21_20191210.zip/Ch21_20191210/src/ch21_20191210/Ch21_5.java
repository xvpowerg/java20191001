/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch21_20191210;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
public class Ch21_5 {
    public static void main(String[] args) {
        
        try{
            File myFile = new File("C:\\MyDir\\myFile.txt");
            File fileOut = new File("C:\\MyDir\\myFile_copy.txt");
            FileInputStream fileIn = new FileInputStream(myFile); 
            FileOutputStream fileOutStr = new FileOutputStream(fileOut);            
            int data = -1;
            while(   (data = fileIn.read()) != -1  ){
                   // System.out.println(data);
                    fileOutStr.write(data);                    
            }
            
        }catch(FileNotFoundException ex){
            System.out.println(ex);
        }catch(IOException ex){
              System.out.println(ex);
        }
      
        
        
    }
    
}
