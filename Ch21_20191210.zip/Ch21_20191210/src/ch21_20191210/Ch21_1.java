/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch21_20191210;
import java.util.ArrayList;
import java.util.stream.Collectors;
import java.util.List;
import java.util.Map;
import java.util.LinkedList;
import java.util.LinkedHashMap;
public class Ch21_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     ArrayList<String> list = new ArrayList<>();
     list.add("Ken");
     list.add("Vivin");
     list.add("Lindy");
     list.add("Join");
    list.add("Howard");
    list.add("Ben");
//    List<Integer> lenList= 
//            list.stream().map(n->n.length()).collect(Collectors.toList());
//    System.out.println(lenList);
//     LinkedList<String> linkList =  list.stream().filter((s)->s.length() > 3).
//         collect(Collectors.toCollection(LinkedList::new));
//     System.out.println(linkList);
    //重複Key會出錯
//Map<Integer,String> myMap = list.stream().filter(s->s.length() > 3).
//        collect(Collectors.
//        toMap(s->s.length(), 
//             s->s));
//     System.out.println(myMap);

LinkedHashMap<Integer,String> myMap = list.stream().filter(s->s.length() > 3).
        collect(Collectors.
        toMap(String::length, 
             String::new,
             (ov,nv)->{return ov +":"+ nv;},
             LinkedHashMap::new));
     System.out.println(myMap);


    }
    
}
