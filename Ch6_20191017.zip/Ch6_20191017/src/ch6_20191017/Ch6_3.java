/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20191017;

/**
 *
 * @author xvpow
 */
public class Ch6_3 {
    //Overloding 多載
    //方法名稱要一樣　參數的數量或類型不一樣
    static String pow(int a,int n,String msg){
//        int ans = 1;
//        for (int i =1;i<=n;i++){
//            ans *= a;
//        }
        return msg+":"+pow(a,n);
    }
    static int pow(int a,int n){
        int ans = 1;
        for (int i =1; i<=n ;i++){
            ans *= a;
        }
        return ans;
    }
    
    //幫我寫一個int max(int,int)
    //幫我寫一個float max(float float);
    static int max(int a,int b){
        return a > b ? a: b;
    }
    
    static float max(float k,float b ){
        return k > b ? k : b;
    }
    
    public static void main(String[] args) {
      System.out.println(pow(2,3,"答案"));
     System.out.println(pow(1,3));
     System.out.println(pow(2,5));
     System.out.println(pow(2,7));
      System.out.println(max(2.6f,1.5f));
     System.out.println(max(21,68));
    }
    
}
