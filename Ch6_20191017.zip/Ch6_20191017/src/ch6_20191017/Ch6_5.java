/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20191017;

public class Ch6_5 {
        //1個參數以上時 必須有一組肯定的參數
        static void test1(int a,float b){
            System.out.println("int float");
        }
        static void test1(int a,int b){
            System.out.println("int int");
        }
        
        static void test2(int a,float b){
              System.out.println("int float");
        }
        static void test2(float a,int b){
            System.out.println("float int");
        }
    public static void main(String[] args) {
        
        test1(2,10);
        //test2(2,5);
        
    }    
}
