/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20191017;

/**
 *
 * @author xvpow
 */
public class Ch6_6 {
        
       static void myLoop(int n){
              System.out.println("Loop Start "+n);
            if (n <= 5){
                System.out.println("IF Start "+n);
                myLoop(n + 1);
                System.out.println("IF End "+n);
            }
             System.out.println("Loop End "+n);
        }
       
       static int factorial(int n){
           if (n == 1) return 1;
           return factorial(n - 1) * n;
       }
   
    public static void main(String[] args) {
    
        //myLoop(1);
        System.out.println(factorial(6));
    }
    
}
