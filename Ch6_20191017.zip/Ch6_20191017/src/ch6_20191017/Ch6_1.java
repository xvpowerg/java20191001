/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20191017;
public class Ch6_1 {
    public static void main(String[] args) {
      //手動封箱
        Integer integer1 = Integer.valueOf(56);
      //自動封箱  
        Integer integer2 = 51;
      //手動解封箱
      int value =integer1.intValue();
      //自動解封箱
      int value2 = integer2;      
      System.out.println(integer2+":"+value2);
      //所非基本型態都不要用==比較
    Integer integer3 = Integer.valueOf(56);
    Integer integer4 = Integer.valueOf(56);
    //Integer.valueOf 有一個暫存 可暫存的數字區間-128~127
    System.out.println(integer3 == integer4);
     
    Integer integer5 = Integer.valueOf(128);
    Integer integer6 = Integer.valueOf(128);   
    System.out.println(integer5 == integer6);
    System.out.println(integer5.equals(integer6));
    
    //愛考  java.lang.NullPointerException
    Integer integer7 = null;
    Integer integer8 = 12;
    int value3 = integer7 + integer8;
    System.out.println(value3);
    
    
    }
    
}
