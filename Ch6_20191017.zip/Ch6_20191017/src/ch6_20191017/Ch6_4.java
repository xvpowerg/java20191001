/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20191017;

/**
 *
 * @author xvpow
 */
public class Ch6_4 {

    //考試愛考
    /*
     多載規則
    1 一模一樣類型
    2 相同類型可相容
    3 不同類型可相容
    4 轉成封箱類型
    */
    static void test1(int v){
        System.out.println("Test1 int");
    }
    static void test1(float v){
        System.out.println("Test1 float");
    }
    
    static void test2(short s1){
        System.out.println("test2 short");
    }
   static void test2(float s1){
        System.out.println("test2 float");
    }
   
   static void test3(short s2){
       System.out.println("test3 short");
   }
   static void test3(Integer s2){
       System.out.println("test3 Integer");
   }
   
   static void test4(long s3){
       System.out.println("test4 long");
   }
    
   static void test4(float s3){
       System.out.println("test4 float");
   }
   
   static void test5(short s2){
       System.out.println("test5 short");
   }
   static void test5(Float s2){
       System.out.println("test5 Float");
   }
   
    public static void main(String[] args) {
      test1(20);
      short s1 = 20;
      test2(20);
      test2(s1);
      
      test3(15);      
      test4(18);
      //25 會轉成Integer 但是 Float不相容Integer 所以出錯
      //test5(25);
    }
    
}
