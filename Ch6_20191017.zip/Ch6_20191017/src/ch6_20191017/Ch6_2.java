package ch6_20191017;

public class Ch6_2 {

    public static void main(String[] args) {
        
        Boolean b1 =  Boolean.valueOf(false);
        System.out.println(b1);
        //parseBoolean 只要不是true不分大小寫就回傳false
       boolean b2 =  Boolean.parseBoolean("true");
        System.out.println(b2);
      boolean b3 =  Boolean.parseBoolean("tRue");
        System.out.println(b3);
      boolean b4 =  Boolean.parseBoolean("tRue");  
       System.out.println(b4);
    }
    
}
