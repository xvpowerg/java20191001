/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20191017;
import java.util.Scanner;
import java.util.Random;
public class Ch6_7 {
    static void game(int max){
       Scanner scann = new Scanner(System.in);    
      Random ran = new Random();
      int min=1;
      int guess = ran.nextInt(max) +1;
      while(true){
          System.out.printf("%d~%d:",min,max);
          int input = scann.nextInt();
          if (input == guess){
              System.out.println("猜對了!");
              break;
          }else if(input > guess){
              max = input;
          }else{
              min = input;
          }          
      }
    } 
    
    public static void main(String[] args) {
          //1~20
      //1~40
      //1~60
      //1~100
        int[] maxs = {20,40,60,100};
        for (int max : maxs){
             game(max);
        }       
    }
   
}
