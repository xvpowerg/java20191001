/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20191001;

public class Ch1_1 {

    public static void main(String[] args) {
        
       //System.out.println("Hello!");      
       /* 基本型態 Primitive Type
        整數類
         byte -128~127
         short -32768~32767
         int 32bit default
         long 64bit
        浮點數類
         float 32bit
         double default
       字元
         char 0~65535
       boolean
           看jvm 可能是1個bit
       */      
       
       int value1 = 10;
       //因為編譯器不知道value3修改的數值，所以這裡必須加上final 
       //這時 value2 + value3就回傳byte類型      
       final byte value2 = 25;
       final byte value3 = 27;
       System.out.println("value1:"+value1);
       System.out.println("value2:"+value2);          
       byte vlaue4 = value2 + value3;
       
       
    }
    
}
