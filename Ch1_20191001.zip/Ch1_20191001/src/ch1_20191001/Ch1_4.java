/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20191001;

/**
 *
 * @author xvpow
 */
public class Ch1_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      //不會考 補充說明
      //& | ^
      int v1 = 115;//1110011
      int v2 = 92; //1011100
      System.out.println(v1 & v2);
     System.out.println(v1 | v2);
      System.out.println(v1 ^ v2);
      
      int ans = 0b1010000;
      System.out.println(ans);
      ans = 0b1111111;
     System.out.println(ans);
     ans = 0b0101111; 
   System.out.println(ans);   
   
   int v3 = 3;
   int n = 1;
   //v3 * 2^n
   System.out.println(v3 << n); 
   n = 2;
   System.out.println(v3 << n); 
   n = 3;
   System.out.println(v3 << n); 
     System.out.println("========"); 
   int v4 = 128;
   //v4 / 2 ^ n
    n = 1;    
   System.out.println(v4 >> n);
    n = 2;
   System.out.println(v4 >> n); 
    n = 3;
   System.out.println(v4 >>n);   
    }
    
}
