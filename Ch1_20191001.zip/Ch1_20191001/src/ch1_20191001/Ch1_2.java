/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20191001;

/**
 *
 * @author xvpow
 */
public class Ch1_2 {

    
    public static void main(String[] args) {
       /*
        運算子優先順序 必須要記
        ()
        - + ++ --
        * / %
        + -
        > =  < >= <= == !=
        &&       
        ||
        */
       int value = 1;
       int show = value++;
       System.out.println(value+":"+show);
       
       int value2 = ++value;
       System.out.println(value+":"+value2);
         
        int k  = 2;
        int ans = 5 + ++k * 3 - k++;
                 //5 + 3 * 3 - 3
                 //5 + 9 - 3
                 //14 - 3 =11                 
        System.out.println(ans);
        System.out.println(k);        
    }
    
}
