/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20191001;

/**
 *
 * @author xvpow
 */
public class Ch1_3 {
    public static void main(String[] args) {
         //邏輯運算子
         //&& 且 兩邊為真才為真 當左邊為為false 會有短路現象 簡單判斷是否為False寫左邊         
         // &  無短路現象
         //|| 或 單邊為真就是真 當左邊為為true  會有短路現象 簡單判斷是否為True寫左邊         
         //| 無短路現象
         //! 反向 唱反調 
         //^ 互斥  一真一假才為真 
        
         boolean b1 = true;
         boolean b2 = false;
         System.out.println(b1 && b2 );//fasle
         System.out.println(b1 || b2 );//true
        System.out.println(b1 ^ b2 );//true
         System.out.println(!b1 );//false
       System.out.println("==============" );      
         b1 = true;
         b2 = true;
         System.out.println(b1 && b2 );//true
         System.out.println(b1 || b2 );//true
        System.out.println(b1 ^ b2 );//false
         System.out.println(!b1 );//false 
    }
    
}
