/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20191029;

import java.io.IOException;
import java.io.FileNotFoundException;
public class TestOverride2 extends TestOverride1{
   public void testPublic(){
        System.out.println("testPublic TestOverride2");
    }
  
     protected void testProtected(){
        System.out.println("testProtected TestOverride2");
    }
     
    void testDefault(){
        System.out.println("testDefault TestOverride2");
    }
    //新的一個方法 因為子類看不到 所以也不會出錯
     private void testPrivate(){
          System.out.println("testPrivate TestOverride2");
    } 
     @Override
      public int getValue(){
        return 10;
    }
     public TestOverride2 getTestOverride1(){
        return null;
    }
      public void testException() throws FileNotFoundException{
        
      }
     
     
}
