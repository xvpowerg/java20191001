/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20191029;
import java.io.IOException;
/**
 *
 * @author xvpow
 */
public class TestException {
    public void testUnchatch(){
        System.out.println("testUnchatch 1");
        if (true){
            throw new NullPointerException();
         }
            System.out.println("testUnchatch 2"); 
    }
    
    public void testCatch() throws IOException{
        throw new IOException();
    }
    
    public void testMyExc1() throws MyException1{
        throw new MyException1("非必要例外檢測的錯誤!!");
    }
    
    public void testMyExc2(String msg)throws MyException2{
        throw new MyException2(msg);
    }
    
}
