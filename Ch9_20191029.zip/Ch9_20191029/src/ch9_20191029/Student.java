/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20191029;

/**
 *
 * @author xvpow
 */
public class Student {
    private int id;
    private String name;
    private int age;
    public Student(int id,String name,int age){
        this.id = id;
        this.name = name;
        this.age = age;
    }
    public int getId(){
        return id;
    }
    public String getName(){
        return name;
    }
    public int getAge(){
        return age;
    }
    public String toString(){
        return this.getId()+":"+this.getName()+":"+this.getAge();
    }
    
    public boolean equals(Object obj){
        if (obj == null || obj instanceof Student == false){
            return false;
        }
        Student tmp = (Student)obj;
        boolean ans =this.age == tmp.age && 
                this.id == tmp.id && this.getName().equals(tmp.getName());
        return ans;
    }
    
}
