/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20191029;

/**
 *
 * @author xvpow
 */
public class Ch19_5 {


    public static void main(String[] args) {
        Student[] st1 = new Student[3];
        st1[0]  =new Student(100,"Ken",20);
        st1[1]  =new Student(60,"Vivin",40);
        st1[2]  =new Student(70,"Lindy",52);
        String msg = "";
        for (Student st : st1){
            msg+=st+" ";
        }
        System.out.println(msg);
        
        
        
    }
    
}
