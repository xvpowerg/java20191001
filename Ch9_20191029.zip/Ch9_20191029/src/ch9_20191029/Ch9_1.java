/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20191029;
import java.io.IOException;
public class Ch9_1 {
    public static void main(String[] args)throws IOException {
        System.out.println("Main Start");
            //例外有分兩種
            //不一定要catch
            TestException te1 = new TestException();
            //te1.testUnchatch();
            //必須要 catch
            try{
                //可能拋出錯誤
                te1.testCatch();
              //catch 幫我接收一IOException個錯誤 放到ex變數
            }catch(IOException ex){
                System.out.println(ex);
            }
            te1.testCatch();
            System.out.println("Main end");
        
    }
    
}
