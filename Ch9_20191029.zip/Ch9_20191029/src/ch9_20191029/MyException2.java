/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20191029;
//在繼承樹上沒有RuntimeException的都是必要例外
public class MyException2 extends Exception{
    public MyException2(){
        
    }
    public MyException2(String msg){
        super(msg);
    }
}
