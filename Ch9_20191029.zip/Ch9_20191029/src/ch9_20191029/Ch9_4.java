/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20191029;

/**
 *
 * @author xvpow
 */
public class Ch9_4 {

    public static void main(String[] args) {
      Student st1 = new Student(100,"Ken",31);
      Student st2 = new Student(100,"Ken",31);
        System.out.println(st1);
    System.out.println(st1.getClass().getName()+"@"+Integer.toHexString(st1.hashCode()));
      System.out.println(st1.equals(st2));
    }
    
}
