/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20191029.test;
import ch9_20191029.TestOverride1;
/**
 *
 * @author xvpow
 */
public class TestOverride3  extends TestOverride1{
     public void testPublic(){
        System.out.println("testPublic TestOverride3");
    }
     @Override //檢查Override 是否正確
    protected void testProtected(){
        System.out.println("testProtected TestOverride3");
    }
    //因為跨package default讀取權限的方法子類也看不道 所以 不算複寫    
    void testDefault(){
        System.out.println("testDefault TestOverride3");
    }
    
    private void testPrivate(){
          System.out.println("testPrivate TestOverride3");
    }
}
