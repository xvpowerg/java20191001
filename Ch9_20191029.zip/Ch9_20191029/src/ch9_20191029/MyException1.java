/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20191029;
//所有unCatch 都是繼承RuntimeException
public class MyException1 extends RuntimeException{
    MyException1(){        
    }
    MyException1(String msg){
        super(msg);
    }
}
