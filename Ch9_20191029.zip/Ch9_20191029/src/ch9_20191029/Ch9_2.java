/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20191029;

/**
 *
 * @author xvpow
 */
public class Ch9_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
   
           // throw new MyException1();
           
           TestException te = new TestException();
           try{
            //te.testMyExc1(); 
            te.testMyExc2("我是必要例外檢測");
           }catch(MyException1 ex){
               System.out.println(ex);
           }catch(MyException2 ex){
              System.out.println(ex); 
           }
                     
    }
    
}
