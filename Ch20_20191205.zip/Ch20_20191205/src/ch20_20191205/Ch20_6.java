/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch20_20191205;

import java.util.ArrayList;
import java.util.Comparator;

/**
 *
 * @author xvpow
 */
public class Ch20_6 {
    public static void main(String[] args) {
       ArrayList<Person> list = new ArrayList<>();
        Person p1 = new Person("Ken",86000);
        Person p2 = new Person("Vivin",51000);
       Person p3 = new Person("Iris",78000);
       Person p4 = new Person("Join",32000);
       Person p5 = new Person("Lindy",54000);
       list.add(p1);
        list.add(p2);
        list.add(p3);
        list.add(p4);
        list.add(p5);
        
        //1 薪資大於6萬的人的姓名
//        list.stream().filter((p)->p.getSalary() > 60000).map(p->p.getName().get()).
//                forEach(System.out::println);
        //2 排序使用薪資做排序
//          list.stream().sorted(Comparator.<Person,Integer>
//                  comparing(Person::getSalary)).forEach(System.out::println);
    int sum =    list.stream().mapToInt(p->p.getSalary()).sum();
    System.out.println(sum);
    
   
    
    }
    
}
