/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch20_20191205;

import java.util.ArrayList;
import java.util.Optional;

/**
 *
 * @author xvpow
 */
public class Ch20_5 {

    public static void main(String[] args) {
         ArrayList<String> list = new ArrayList();
        list.add("Ken");
        list.add("Vivin");
        list.add("Join");
        list.add("Iris"); 
        list.add("Join");
        
       // list.stream().skip(2).forEach(System.out::println);
        
        //list.parallelStream().forEach(System.out::println);
       // list.parallelStream().forEachOrdered(System.out::println);
       
        Optional<String> op= list.stream().reduce((o,n)->o+n);
        System.out.println(op.get());
        
        list.stream().map((n)->n.toUpperCase()).forEach(System.out::println);
        
        
        
    }
    
}
