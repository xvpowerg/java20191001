/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch20_20191205;

/**
 *
 * @author xvpow
 */
public class Ch20_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Person p1 = new Person();
        p1.setName("Ken");
        p1.setSalary(56000);
        
        p1.getName().ifPresent((name)->{
                if (name.length() > 10 || name.length() < 2){
                    System.out.println("錯誤的姓名");
                }
        });
        
        
//        if (p1.getName() == null){
//            throw new  RuntimeException("Name NotNull");
//        }
//        if (p1.getName().length() > 10 || p1.getName().length() < 2){
//            System.out.println("姓名文字過短");
//        }
    }
    
}
