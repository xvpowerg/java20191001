/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch20_20191205;
import java.util.stream.Stream;
import java.util.List;
import java.util.ArrayList;
import java.util.Optional;

public class Person {
    private String name;
    private int salary;
    private Optional<String> nameOption;
    private List<Person> teams = new ArrayList<>();
    Person(){
        
    }
     Person(String name,int salary){
        this.name = name;
        this.salary = salary;
    }
     public void addMember(Person p){
         teams.add(p);
     }
     public Stream<Person> getMemberStream(){
         return teams.stream();
     }
    public Optional<String> getName(){
        return  Optional.ofNullable(name);
    }
    public void setName(String name){
        this.name = name;
    }
     public int getSalary(){
        return salary;
    }
    public void setSalary(int salary){
        this.salary = salary;
    }
    
    public String toString(){
        return name+":"+salary;
    }
}
