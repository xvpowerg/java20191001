/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch20_20191205;
import java.util.Optional;
public class Ch20_3 {

  
    public static void main(String[] args) {
         Optional<String> strOp =  Optional.empty();
        // System.out.println(strOp.get());
         //不可null 使用 of
         Optional<String> strOp2 = Optional.of("Vivin");
         System.out.println(strOp2.get());
        //可null ofNullable
        Optional<String> strOp3 = Optional.ofNullable("Ken");
          System.out.println(strOp3.get());
        
    }
    
}
