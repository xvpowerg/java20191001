/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch20_20191205;

import java.util.Optional;

/**
 *
 * @author xvpow
 */
public class Ch20_4 {

   static String genRandom(){
          StringBuffer sb = new StringBuffer();
            java.util.Random ran = new  java.util.Random();
            int len = ran.nextInt(5) + 1;
            for (int i= 1; i<= len;i++){
               char tmp =(char) (ran.nextInt(26)+'A');
               sb.append(tmp);
            }
            return sb.toString();
   }
    public static void main(String[] args) {
        Optional<String> strOp =  Optional.empty();
        if (strOp.isPresent()){
            String st1 = strOp.get();
            System.out.println(st1);
        }
//      Optional<String> strOp2 =  Optional.empty();    
//       String emptyStr =  strOp2.orElse("Empty");
//       System.out.println(emptyStr);
//       strOp2 =  Optional.of("Test1");
//       emptyStr =  strOp2.orElse("Empty");
//       System.out.println(emptyStr);
       

//     String value =   strOp3.orElseGet(()->{
//            StringBuffer sb = new StringBuffer();
//            java.util.Random ran = new  java.util.Random();
//            int len = ran.nextInt(5) + 1;
//            for (int i= 1; i<= len;i++){
//               char tmp =(char) (ran.nextInt(26)+'A');
//               sb.append(tmp);
//            }
//            return sb.toString();
//       });
       
     Optional<String> strOp3 =  Optional.empty();    
     String value = strOp3.orElseGet(Ch20_4::genRandom);
     System.out.println(value);
    
     strOp3.orElseThrow(RuntimeException::new);
    }
    
}
