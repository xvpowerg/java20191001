/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch20_20191205;

import java.util.ArrayList;

/**
 *
 * @author xvpow
 */
public class Ch20_7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         ArrayList<Person> list = new ArrayList<>();
        Person p1 = new Person("Ken",86000);
        Person p2 = new Person("Vivin",51000);
       Person p3 = new Person("Iris",78000);
       Person p4 = new Person("Join",32000);
       Person p5 = new Person("Lindy",54000);
       list.add(p1);
       p1.addMember(p3);
       p1.addMember(p5);
       list.add(p2);
       p2.addMember(p4);
       list.stream().flatMap(Person::getMemberStream).forEach(System.out::println);        
    }
    
}
