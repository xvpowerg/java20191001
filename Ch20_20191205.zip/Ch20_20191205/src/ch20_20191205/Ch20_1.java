/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch20_20191205;
import java.util.ArrayList;
import java.util.Optional;
/**
 *
 * @author xvpow
 */
public class Ch20_1 {


    public static void main(String[] args) {
       ArrayList<String> list = new ArrayList();
        list.add("Ken");
        list.add("Vivin");
        list.add("Join");
        list.add("Iris"); 
        list.add("Join");
        
        Optional<String> op1 =  list.stream().findAny();
        Optional<String> op2 =  list.stream().findFirst();
        System.out.println(op1.get());
       System.out.println(op2.get());
       
       Optional<String> op3 =  list.stream().parallel().findAny();
        Optional<String> op4 =  list.stream().parallel().findFirst();
        System.out.println(op3.get());
       System.out.println(op4.get());  
       
//        System.out.println("count:"+list.stream().count());
//        //distinct 過濾重複
//       System.out.println("count:"+list.stream().distinct().count());
//       boolean b1 =  list.stream().noneMatch((s)->{
//           System.out.println("noneMatch!!");
//           return s.length() > 10;});
//       System.out.println(b1);
//        boolean b2 =  list.stream().noneMatch((s)->{
//           System.out.println("noneMatch!!");
//           return s.length() > 3;});
//         System.out.println(b2);
    }
    
}
