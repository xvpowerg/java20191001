/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20191008;

/**
 *
 * @author xvpow
 */
public class Ch3_3 {

    public static void main(String[] args) {
       //java 陣列非基本型態
       int[] array1 = new int[5];
       array1[0] = 7;
       array1[2] = 9;
       array1[4] = 32;
        
//       for (int i =0  ; i < array1.length ; i++ ){
//           System.out.print(array1[i]+" ");
//       } 

//foreach 迴圈
//         for (int v : array1){
//             System.out.print(v+" ");
//         }

//使用Stream
    java.util.Arrays.stream(array1).forEach(System.out::println);
 
    
    
    }
    
}
