/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20191008;

/**
 *
 * @author xvpow
 */
public class Ch3_2 {

    public static void main(String[] args) {
  
//        int i =5;        
//        while(i >= 1){
//           System.out.println(i--);
//        }
//do while 尾巴必須加上;號
        int i =1;
        do{
            System.out.println(i);
        }while(++i<6);
        
            
        
        
//        String values = "ABCDEF";
//        String tmp = null;
//        while( (tmp = values.substring(0, values.length() - 1)).length() > 1 ){
//            System.out.println(tmp);
//            values = tmp;
//        }
        
        
        
    }
    
}
