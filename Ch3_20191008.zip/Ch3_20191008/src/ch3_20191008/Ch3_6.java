/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20191008;

/**
 *
 * @author xvpow
 */
public class Ch3_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        int[] array1 = new int[3];
        
        array1[1] = 2;
        array1[2] = 3;
        //java.lang.ArrayIndexOutOfBoundsException
      //  array1[3] = 4;
        //要記起來！！！
        //陣列的預設值
        //基本型態
        //整數系列　預設值：0
         byte[] data = new byte[3];
         System.out.println(data[1]);
        //浮點數系列　預設值：0.0
        float[] point = new float[5];
         System.out.println(point[1]);
        //字元　預設值：空白字元
        char[] empty= new char[2];
        System.out.println(empty[1]);
        //布林 預設值：false
         boolean[] b1 = new boolean[2];
        System.out.println(b1[1]);
        //其他  預設值：null
        String[] str = new String[3];
        System.out.println(str[1]);
        
        
        String value = str[1];
        switch(value){
            case " ":
                System.out.println("Empty");
                break;
            default:
                System.out.println("Default");
                break;
        }
        
    }
    
}
