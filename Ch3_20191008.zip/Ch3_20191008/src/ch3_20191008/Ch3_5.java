/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20191008;

/**
 *
 * @author xvpow
 */
public class Ch3_5 {


    public static void main(String[] args) {
        // 愛考的
       //陣列宣告方式
       int[] array1 = new int[3];
       int array2[] = new int[3];      
       //宣告時給予初始值
       int[] array3 = {5,6,7,8};
       //最特別[]不可填長度       
       //假設已宣告後想再重新給予初始值
       int[] array4 = new int[]{7,4,3,1};
       System.out.println(array4[1]);
       array4 = new int[]{6,7,8};
       System.out.println(array4[1]);
       
       
    }
    
}
