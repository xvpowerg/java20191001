/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20191008;
import java.util.Arrays;
public class Ch3_8 {

    public static void main(String[] args) {
       //一定考!!!~~
        int[] array1 = {8,1,5,15,3};
        Arrays.sort(array1);
        int index = Arrays.binarySearch(array1, 5);
        System.out.println(index);
        
        String[] array2 = {"cbvs","cbGh","bGh","bdeF"};
        Arrays.sort(array2);
        int index2 = Arrays.binarySearch(array2, "cbGh");
         System.out.println(index);
        
    }
    
}
