/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20191008;
public class Ch3_1 {
    public static void main(String[] args) {
       //break 離開迴圈
       //continue 繼續下次迴圈
       
//        for (int i =1 ; i<=5 ; i++ ){
//            //if (i == 3) break;
//            if (i == 3) continue;
//            System.out.println(i);
//        }

//巢狀迴圈
//         for (int i =1 ; i<=3 ; i++ ){
//              for ( int k = 2; k <=5 ; k++){
//                  //%d 整數 %f 浮點數 %n 段行
//                   System.out.printf("%d*%d=%2d ",i,k,i*k);
//              }              
//              System.out.println();
//        }


//正常巢狀迴圈流程
//    System.out.println("Step 1");
//        for (int i =1 ; i<=3 ; i++ ){
//       System.out.println("Step 2:"+i);
//              for ( int k = 2; k <=5 ; k++){
//                  //%d 整數 %f 浮點數 %n 段行
//                   System.out.println("Step 3:"+k);
//              }              
//           System.out.println("Step 4:"+i);
//        }
//        System.out.println("Step 5");  

//巢狀迴圈流程加了break 或 continue
//   System.out.println("Step 1");
//        for (int i =1 ; i<=3 ; i++ ){
//       System.out.println("Step 2:"+i);
//              for ( int k = 2; k <=5 ; k++){
////                     if (i == 2){
////                         break;
////                     }
//            //System.out.println("Step 3_1:"+k);
//                    if (i == 2){
//                         continue;
//                     }
//                  System.out.println("Step 3_2 :"+k);
//              }              
//           System.out.println("Step 4:"+i);
//        }
//        System.out.println("Step 5");  


//巢狀迴圈流程加了break 或 continue 與 標籤
 System.out.println("Step 1");
        Tag1:
        for (int i =1 ; i<=3 ; i++ ){
       System.out.println("Step 2:"+i);
          Tag2:
              for ( int k = 2; k <=5 ; k++){
                     if (i == 2){
                         break Tag1;
                     }
            //System.out.println("Step 3_1:"+k);
//                    if (i == 2){
//                         continue Tag1;
//                     }
                  System.out.println("Step 3_2 :"+k);
              }              
           System.out.println("Step 4:"+i);
        }
        System.out.println("Step 5");  
    
    }    
}
