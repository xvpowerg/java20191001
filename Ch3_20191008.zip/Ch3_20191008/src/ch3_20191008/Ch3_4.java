/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20191008;

/**
 *
 * @author xvpow
 */
public class Ch3_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    int[] array1 = new int[10000];
     //我希望陣列內容由1開始一直到10000
     
     for (int i =1;i<=10000;i++){
         array1[i - 1] = i;
     }
          
     System.out.println(array1[0]);        
     System.out.println(array1[9999]);            
    }
    
}
