/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20191008;
import java.util.Arrays;
public class Ch3_7 {

    public static void main(String[] args) {
      
        //Arrays　工具        
//        int[] array1 = {8,9,7,1,2,5,3,4};
//        for (int v : array1){
//            System.out.print(v+" ");
//        }
//        System.out.println();
//        //小到大遞增排序法  快速排序法
//        Arrays.sort(array1);
//        for (int v2 :array1){
//            System.out.print(v2+" ");
//        }

        //字串排序　
          //大寫英文字母　小於　小寫英文字母
          //a > A  A < a
        //順序:比較由左至右，一個字元一個字元比
         //規則：
        // 找到誰比較大那就是誰大
        // 都一樣大就看誰比較長　長的大
        
//     String[] strArray1 = {"C","b","A"} ;    
//        Arrays.sort(strArray1);
//        for (String v : strArray1){
//            System.out.print(v+" ");
//        }
     String[] strArray2 = {"cbG","cbK","cFb"};   
        Arrays.sort(strArray2);
        for (String v : strArray2){
            System.out.print(v+" ");
        }
        
        char c1 = '雙';
        System.out.println((int)c1);
    }
    
}
