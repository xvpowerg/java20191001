/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Scanner;
public class Ch4_3 {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        System.out.println("請輸入西元年:");
        int year = scan.nextInt();
            if (year % 400 == 0 || year % 4 ==0 && year % 100 != 0){
                  System.out.printf("%d是閏年%n",year);        
            }else{
                System.out.printf("%d不是閏年%n",year);   
            }
        
        if (year % 400 == 0){
            System.out.printf("%d是閏年%n",year);            
        }else{
             if (year % 4 == 0){
                  if (year % 100 == 0){
                        System.out.printf("%d不是閏年%n",year);            
                  }else{
                    System.out.printf("%d是閏年%n",year);   
                  }                 
             }else{
                   System.out.printf("%d不是閏年%n",year);
             }            
        }
        
        
        /*System.out.println("請輸入預算:");
        int budget = scan.nextInt();
        if (budget >= 5000){
            System.out.println("台北");
        }else if(budget >= 2500){
             System.out.println("台中"); 
        }else if(budget >= 1500){
              System.out.println("台南"); 
        }else{
            System.out.println("高雄");
        }*/
        
        /*int pwd = 1234;
        System.out.println("請輸入密碼:");
        int inPwd = scan.nextInt();
        if (inPwd == pwd){
            System.out.println("登入成功");
        }else{
             System.out.println("登入失敗");
        }*/
        
    }
}
