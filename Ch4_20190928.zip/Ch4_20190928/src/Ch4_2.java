/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Scanner;
public class Ch4_2 {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        System.out.print("輸入姓名:");
        String inputname = scan.next();
        System.out.printf("Hi %s%n",inputname);
        System.out.print("中翻英這是一本書");
          scan.nextLine();
        String input =   scan.nextLine();
        System.out.println(input);
        
       /* System.out.print("輸入2個小數 用空白隔開:");
        double d1 = scan.nextDouble();
        double d2 = scan.nextDouble();
        System.out.printf("%.2f + %.2f = %.2f%n",d1,d2,d1+d2);*/
        
        /*System.out.println("輸入西元年:");
        int year = scan.nextInt();
        System.out.printf("西元%d年是民國%d年%n",year,year-1911);*/
    }
}
