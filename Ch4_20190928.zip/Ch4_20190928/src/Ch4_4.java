/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Scanner;
public class Ch4_4 {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        System.out.println("請輸入年齡:");
        int age = scan.nextInt();
        
        
       String msg = "";
       msg = age >=18 ? "成年" : "未成年";
         /*if (age >= 18){
          msg = "成年";
        }else{
            msg = "未成年"; 
        }*/
          System.out.println(msg);
    }
}
