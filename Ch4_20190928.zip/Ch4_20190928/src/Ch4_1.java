/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


public class Ch4_1 {
    public static void main(String[] args){
        int a5 = 1,b5 = 1,c5 = 1;
        System.out.printf("a5= %d, b5= %d, c5=%d %n",a5,b5,c5);
        System.out.printf("a5 > b5 || a5 <= c5 = %b%n",a5 > b5 || a5 <= c5);
        System.out.printf("a5==b5 && a5==c5 =%b%n",a5==b5 && a5==c5);
        
        System.out.printf("a5 < b5 || a5++ > c5 = %b%n",a5 <b5 || a5++ > c5);
        System.out.printf("a5 = %d, b5=%d,c5 =%d%n",a5,b5,c5);
        
        System.out.printf("a5<b5 && a5++>c5 = %b%n",a5 < b5 && a5++ > c5);
        System.out.printf("a5 = %d,b5=%d,c5=%d%n",a5,b5,c5);
        
        
        int a6 = 5;
        a6 += 8;
        System.out.println(a6);
        
        int a7 = 257;
        byte a8 = (byte)a7;
        System.out.println(a8);
        
    }
}
