
package ch22_20191212;
import java.io.File;
import java.io.ObjectOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
public class Ch22_5 {

    public static void main(String[] args) {
      String value = "Ken";
        // 序列化 把物件變檔案
        File file = new File("c:\\MyDir\\value.obj");
        try(FileOutputStream fout = new FileOutputStream(file);
            ObjectOutputStream oos = new ObjectOutputStream(fout);    ){
            oos.writeObject(value);
        }catch(IOException ex){
            System.out.println(ex);
        }
       
        
        
    }
    
}
