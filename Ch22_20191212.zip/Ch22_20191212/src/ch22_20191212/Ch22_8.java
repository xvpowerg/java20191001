/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch22_20191212;
import java.io.File;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
public class Ch22_8 {
    
        //反序列化
     public static void main(String[] args) {
           File f1 = new File("c:\\MyDir\\student.obj");
           try(FileInputStream fis=  new FileInputStream(f1);
              ObjectInputStream objIn = new ObjectInputStream(fis);   ){
              Student st1 =  (Student) objIn.readObject();
              System.out.println(st1);
           }catch(IOException | ClassNotFoundException ex){
               System.out.println(ex);
           }
         
     }
}
