/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch22_20191212;
import java.io.Serializable;
public class Student extends Person implements Serializable{
    private transient String name;
    private int age;
    private Book b1 = new Book("A1",100);
    public Student(String name,int age,int height,int weigth){
        super(height,weigth);
        this.name = name;
        this.age = age;
    }
    
    public String toString(){
        return name+":"+age+":"+super.toString();
    }
}
