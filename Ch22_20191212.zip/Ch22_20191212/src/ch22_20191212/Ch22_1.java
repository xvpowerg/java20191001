/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch22_20191212;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.File;
import java.io.IOException;

public class Ch22_1 {

    public static void main(String[] args) {
    
        File src = new File("C:\\MyDir\\test.zip");
        File target = new File("C:\\MyDir\\test_copy.zip");
        
        try(FileInputStream fin = new FileInputStream(src);
            FileOutputStream fount = new FileOutputStream(target);){
            byte[] buffer = new byte[2048];
            int length = -1;
            System.out.println("開始!!");
            while( (length = fin.read(buffer)) != -1 ){
                fount.write(buffer, 0, length);
            }
             System.out.println("結束!!");
        }catch(IOException ex){
           System.out.println(ex);
        }
        
        
        
    }
    
}
