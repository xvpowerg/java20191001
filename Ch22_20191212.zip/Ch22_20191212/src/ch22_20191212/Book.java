/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch22_20191212;
import java.io.Serializable;

public class Book implements Serializable{
    private String isbn;
    private int price;
    public Book(String isbn,int price){
        this.isbn = isbn;
        this.price = price;
    }
    public String toString(){
        return isbn+":"+price;
    }
}
