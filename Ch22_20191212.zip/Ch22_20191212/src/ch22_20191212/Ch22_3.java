/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch22_20191212;
import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
public class Ch22_3 {
    
    public static void main(String[] args) {
        File file = new File("C:\\MyDir\\myFile.txt");
           try( BufferedReader fr = new BufferedReader(new FileReader(file));){
            String data = null;
            while ( (data = fr.readLine()) !=null){
                    System.out.println(data);
            }
        }catch(FileNotFoundException ex){
            System.out.println(ex);
        }catch(IOException ex){
           System.out.println(ex);     
        }
        
        
//        try( FileReader fr = new FileReader(file);){
//            int data = -1;
//            while ( (data = fr.read()) != -1){
//                    System.out.print((char)data);
//            }
//        }catch(FileNotFoundException ex){
//            System.out.println(ex);
//        }catch(IOException ex){
//           System.out.println(ex);     
//        }
       
    }
    
}
