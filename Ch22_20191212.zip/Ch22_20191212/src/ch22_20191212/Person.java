/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch22_20191212;
import java.io.Serializable;

public class Person implements Serializable {
    private int height;
    private int weight;
    Person(){
        
    }
    Person (int height,int weight){
        this.height = height;
        this.weight = weight;
    }
    public String toString(){
        return height+":"+weight;
    }
}
