/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch22_20191212;
/**
 *
 * @author xvpow
 */
public class TestClose implements AutoCloseable {
    private String name;
    public void close()throws Exception{
        System.out.println("close!!"+name);
        
        throw new Exception("Exception:"+name);
    }
    TestClose(String name){
        this.name = name;
    }
    
    public String toString(){
        return name;
    }
}
