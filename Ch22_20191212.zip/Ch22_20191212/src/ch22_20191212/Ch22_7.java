/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch22_20191212;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
public class Ch22_7 {

  
    public static void main(String[] args) {
      Student st1 = new Student("Ken",21,172,56);
        File f1 = new File("c:\\MyDir\\student.obj");
        try( FileOutputStream fout = new FileOutputStream(f1);
              ObjectOutputStream oos = new   ObjectOutputStream(fout);){
            oos.writeObject(st1);
        }catch(IOException  ex){
            System.out.println(ex);
        }
       
        
        
    }
    
}
