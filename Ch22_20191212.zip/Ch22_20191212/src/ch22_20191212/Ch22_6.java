/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch22_20191212;
import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
public class Ch22_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      // 反序列化 把檔案變物件
        File file = new File("c:\\MyDir\\value.obj");
        try(FileInputStream fis = new FileInputStream(file);
           ObjectInputStream objIn = new    ObjectInputStream(fis)  ){
           String v1 =   (String)objIn.readObject();
           System.out.println(v1);
        }catch(FileNotFoundException | ClassNotFoundException ex){
            System.out.println(ex);
        }catch(IOException ex){
            System.out.println(ex);
        }
    }
    
}
