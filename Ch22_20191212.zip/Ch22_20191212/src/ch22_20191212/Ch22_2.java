/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch22_20191212;

/**
 *
 * @author xvpow
 */
public class Ch22_2 {

    public static void main(String[] args) {
      //close 呼叫順序tc2 先 在tc1
      //close順序與物件建立順序相反(reverse)
        try( TestClose tc1 = new TestClose("Colse1");
            TestClose tc2 = new TestClose("Colse2");){
            System.out.println("Body.......1");
            throw new Exception("Exception .... 1");
        }catch(Exception ex){
              System.out.println(ex);
         Throwable[] ths =    ex.getSuppressed();
         for (int i =0; i<ths.length ;i++){
              System.out.println(ths[i]);
         } 
        }finally{
          System.out.println("finally.....");  
        }
     
        
        
        
    }
    
}
