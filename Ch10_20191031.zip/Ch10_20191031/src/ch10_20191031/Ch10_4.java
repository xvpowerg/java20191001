/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20191031;

/**
 *
 * @author shihhaochiu
 */
public class Ch10_4 {

    public static void main(String[] args) {
        //所有靜態的或屬性(不分靜態或非靜態)都是遮蔽
        //所有非靜態的方法都是複寫
        
        //遮蔽看類別
        //複寫看物件
        
        TestShading2 ts1 = new  TestShading2();
        //ts1.value1 = 71;
        ts1.setValue1(57);
        ts1.testValue1();
    }
    
}
