/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20191031;

/**
 *
 * @author shihhaochiu
 */

//以下會出錯 因為Test1 無預設建構子
public class Test2 extends Test1 {
  public Test2(){
      super("");
  }
}
