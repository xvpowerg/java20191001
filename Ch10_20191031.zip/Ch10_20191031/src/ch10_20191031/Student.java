/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20191031;
import java.util.Random;
/**
 *
 * @author shihhaochiu
 */
public class Student {
    private String teacherName;
    private String name;
    private int[] scores = new int[10];
    private static int[] numbers = new int[100];
    
    public static void printNumbers(){
        for (int number : numbers){
            System.out.println(number);
        }
        
    }
    //靜態初始
    static {
            Random random = new Random();
         for (int i =0; i<numbers.length ;i++){
             numbers[i] = random.nextInt(30000) + 1;
         }
    }
     //非靜態初始化區塊
      {
     
         for (int i =0;i<scores.length;i++ ){
            scores[i] = -1;
           }
      
     }
  
    public Student(String name,String teacherName){
        this.name = name;
        this.teacherName = teacherName;
        
    }
    
    
    public Student(String name){
        this();
        this.name = name;
        
    }
    public Student(){
      
    }
    public void printScore(){
        for (int s : scores){
            System.out.println(s);
        }
    }
    
}
