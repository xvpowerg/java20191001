/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20191031;

/**
 *
 * @author shihhaochiu
 */
public class TestBlock {
    public TestBlock(){
        System.out.println("TestBlock 1");
    }
    
    {
    System.out.println("noneStatic 1");
    }
    static{
    System.out.println("static 1");
    }
   static{
    System.out.println("static 2");
    }
    
    {
    System.out.println("noneStatic 2");
    }
}
