/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20191031;

/**
 *
 * @author shihhaochiu
 */
public class Ch10_1 {

    public static void main(String[] args) {
        TestStatic ts1 = new TestStatic();
        TestStatic ts2 = new TestStatic();
        
        ts1.nonStaticValue = "Test1";
        ts2.nonStaticValue = "Test2";
        
        //輸出個別獨立
        System.out.println( ts1.nonStaticValue);
        System.out.println( ts2.nonStaticValue);
         System.out.println("===============");
        //靜態的資源是分享的
       ts1.staticValue = "Test1_1";
       ts2.staticValue = "Test1_2";
   
       System.out.println(ts1.staticValue);
       System.out.println(ts2.staticValue);
       //靜態屬類別 非靜態屬物件
     System.out.println("===============");
       System.out.println(TestStatic.staticValue);
       System.out.println(TestStatic.staticValue);
       
       
       
    }
    
}
