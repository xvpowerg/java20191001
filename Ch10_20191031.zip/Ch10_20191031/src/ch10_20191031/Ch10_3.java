/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20191031;

/**
 *
 * @author shihhaochiu
 */
public class Ch10_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
      //  Student.printNumbers();
      //愛考
      // block 順序
      //static nonestatic constructor
      // block 呼叫次數 
      // static 只會呼叫一次
      //nonestatic 每new就呼叫一次
      TestBlock tb = new TestBlock();
      System.out.println("===================");
      TestBlock tb2 = new TestBlock();
    }
    
}
