/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20191031;

/**
 *
 * @author shihhaochiu
 */
public class TestStatic {
    public String nonStaticValue = "";
    public static String staticValue = "";
    
    public static int myValue =95; 
    public  int myStaticInt =95; 
}
