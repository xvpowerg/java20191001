/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20191031;

/**
 *
 * @author shihhaochiu
 */
public class Ch10_6 {

    public static void main(String[] args) {
      
        String names = "Ken,vivin,lindy,Join";
        String[] nameArray= names.split(",");
        for (String v  : nameArray){
            System.out.println(v);
        }
        //累加文字用
        StringBuilder sb = new StringBuilder("A");
         sb.append("B");
        System.out.println(sb);
        
       String v1= "A";
       v1+="B";
       v1+="C"; 
    }
    
}
