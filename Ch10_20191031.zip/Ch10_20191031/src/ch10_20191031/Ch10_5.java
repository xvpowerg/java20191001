/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20191031;

/**
 *
 * @author shihhaochiu
 */
public class Ch10_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      TestShading1 ts1 = new TestShading2();
      ts1.setValue1(59);
      System.out.println(ts1.value1);
     ts1.printTest(); 
        
        
    }
    
}
