/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20191105.erp;
import java.util.ArrayList;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.io.IOException;

import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 *
 * @author shihhaochiu
 */
public  abstract class MyErp {
    private ArrayList<String> readData(){
      //  //Users/shihhaochiu/Documents/mydata/myReport.txt
      
    Path path =  Paths.get("//Users/shihhaochiu/Documents/mydata/myReport.txt");
    ArrayList<String> list = new ArrayList<>();
    try{
      Stream<String> stre =  Files.lines(path);  
      list = stre.collect(Collectors.toCollection(ArrayList::new));
    }catch(IOException ex){
        System.out.println(ex);
    }
        return list;
    }
    
    protected  abstract void reportStyle(ArrayList<String> data);
    
    public void exportReport(){
        ArrayList<String> data = readData();
        reportStyle(data);
    }
    
    
}
