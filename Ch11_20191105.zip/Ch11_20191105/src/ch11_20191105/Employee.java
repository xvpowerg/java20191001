/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20191105;

/**
 *
 * @author shihhaochiu
 */
public class Employee extends Person{
    private int sex;
    public static final int SEX_MALE = 0;
    public static final int SEX_FEMALE = 1;
    
    public Employee(String name,int age,int sex){
        super(name,age);
        this.sex = sex;
    }
    public int getSex(){
        return sex;
    }
}
