/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20191105;


public class Bird {
    private String name;
    private float height;
    private float weight;
    
    public Bird(String name,float height,float weight){
        this.name = name;
        this.height = height;
        this.weight = weight;
    }
    
    public String getName(){
        return name;
    }
    public String toString(){
        return name+":"+height+":"+weight;
    }
}
