/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20191105;


//介面所有的一般方法都是抽象且公開
public interface Fly {
    //預設情況
    //public abstract void flying();
    void flying();
}
