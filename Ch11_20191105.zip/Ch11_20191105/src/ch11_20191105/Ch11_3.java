/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20191105;

/**
 *
 * @author shihhaochiu
 */
public class Ch11_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //耦合度 coupling
        
//        Fly testFly = new FlyBird("DoBe",2,0.5f);
//        testFly.flying();
//        System.out.print(testFly);

            IronManAction ironMan = new IronMan();
            ironMan.flying();
            ironMan.attacking();
            
            Run ironRun = ironMan;
            ironRun.runing();
            
            Duck duck = new Duck("唐老",50f,50f);
            duck.swiming();
            duck.eating();
    }
    
}


