/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20191105.report;
import ch11_20191105.erp.MyErp;
import java.util.ArrayList;
/**
 *
 * @author shihhaochiu
 */
public class MyReport extends MyErp {
    protected void reportStyle(ArrayList<String> data){
        for (String v : data){
            String[] datas = v.split(",");
            System.out.printf("姓名:%s 第一季績效:%d "
                    + "第二季績效:%d 第三季績效:%d "
                    + "第四季績效:%d %n",
                    datas[0],
                    Integer.parseInt(datas[1]),
                      Integer.parseInt(datas[2]),
                       Integer.parseInt(datas[3]),
                       Integer.parseInt(datas[4]));
        }
    }
}
