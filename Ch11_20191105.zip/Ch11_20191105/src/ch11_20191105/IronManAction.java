/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20191105;

/**
 *
 * @author shihhaochiu
 */
//介面可以多重繼承
public interface IronManAction extends Fly,Run,Attack {
    
}
//Swim
//Eat

//Duck  屬於鳥類
//都會游泳
//都會吃魚

