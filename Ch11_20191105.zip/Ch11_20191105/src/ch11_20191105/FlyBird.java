/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20191105;

/**
 *
 * @author shihhaochiu
 */

//類別與介面的關係是實作(implements)
public class FlyBird extends Bird implements Fly {
    public FlyBird(String name,float height,float weight){
        super(name,height,weight);
    }
    
    public void flying(){
        System.out.println(this.getName()+"!!飛飛飛");
    }
}
