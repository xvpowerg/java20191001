/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20191105;

/**
 *
 * @author shihhaochiu
 */
public class Duck extends Bird implements Swim,Eat{
    public Duck(String name,float height,float weight){
        super(name,height,weight);
    }
    
    public void swiming(){
        System.out.println("我不會游泳的鴨子！！");
    }
      public void eating(){
        System.out.println("我吃素！！"); 
    }
}
