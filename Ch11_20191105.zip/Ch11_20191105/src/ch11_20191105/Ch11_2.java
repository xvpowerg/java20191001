/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20191105;
import ch11_20191105.erp.MyErp;
import ch11_20191105.report.MyReport;
import java.util.ArrayList;
/**
 *
 * @author shihhaochiu
 */
public class Ch11_2  extends MyErp{
    public void reportStyle(ArrayList<String>list ){
        list.forEach(System.out::println);
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
//        Ch11_2 ch = new Ch11_2();
//        ch.exportReport();

     MyErp erp = new MyReport();
     erp.exportReport();
    }
    
}
