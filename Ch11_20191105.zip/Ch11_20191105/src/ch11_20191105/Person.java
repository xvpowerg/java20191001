/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20191105;

//只要有抽象方法類別必抽象
//抽象類別可以有實體方法
//抽象方法可以在非抽象方法內呼叫

//抽象方法 不可為私有 與 final
//抽象類別 不可為final

//抽象類別 不可new
public abstract class Person {
    private String name;
    private int age;
    public abstract int getSex();
    public Person(String name,int age){
        this.name = name;
        this.age = age;
    }
    
    
    public String toString(){
        return name+":"+age+":"+getSex();
    }
    
}
