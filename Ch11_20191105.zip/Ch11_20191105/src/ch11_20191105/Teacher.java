/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_20191105;



//一個類別去繼承一個抽象類別
//如果抽象類別有抽象方法
//有兩個解決方法
//1 複寫抽象方法
//2 把目前類別變抽象
public abstract class Teacher extends Person {
    public Teacher(String name,int age){
        super(name,age);
    }
}
