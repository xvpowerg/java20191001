/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20191022;

public class Figture {
    private int id;
    String scale;
    private String character;
    String material;
    //預設建構子
    Figture(){
        //this() 只能寫在建構子
        //並且只能是第一行命令
        this(0,"未填寫",
                "未填寫",
                "未填寫");
    }
    //建構子 建構式  Constructor 
    Figture(int id,String scale,
           String chara,String material){
        //this. 的xxx
        this.id = id;
        this.scale = scale;
        this.character = chara;
        this.material = material;        
    }
    //id 不可小於0 不可大於50000
    //寫入ID
     public void setId(int myId){
         if (myId < 0  || myId > 50000){
             System.out.println("錯誤的ID");
             return;
         }
         id = myId;
     }  
    //取得ID
     public int getId(){
         return id;
     }
    //寫入
    public void setCharacter(String chara){
        if (chara == null || chara.length() > 10 ){
            System.out.println("錯誤的角色!");
            return;//中斷方法
        }
        character = chara;
    }
    //讀取
    public String getCharacter(){
        return character;
    }
    
    void print(){
          System.out.printf("id:%d scale:%s character:%s material:%s %n",  
             id ,
             scale,
             character, 
             material);  
    }
}
