/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20191022;

/**
 *
 * @author xvpow
 */
public class Ch7_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
//        Figture f3 = new 
//        Figture(3,"1:1","炭志郎","樹酯");
//        f3.print();
        
//       Figture f4 = new Figture(); 
//       f4.print();
       
      Test1 t1 = new Test1();
     
    }
    
}
