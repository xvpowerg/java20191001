/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20191022;

/**
 *
 * @author xvpow
 */
public class Ch7_4 {
    public static void main(String[] args) {
      
        //字串所有方法都不會改變字串來源，產生一個新字串
        String msg = "123456789";
        System.out.println(msg.length());
        System.out.println(msg.concat("ABCDEF")); 
        System.out.println(msg);   
        String v1 = "A";
        String v2 = "a";
       System.out.println(v1.equals(v2));
       System.out.println(v1.equalsIgnoreCase(v2));     
       System.out.println(msg.substring(2));
       System.out.println(msg.substring(2,6));
       System.out.println(msg.substring(5,9));
       System.out.println(msg);   
       
    }
    
}

