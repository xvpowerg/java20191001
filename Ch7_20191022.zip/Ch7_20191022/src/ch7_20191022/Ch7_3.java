/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20191022;

/**
 *
 * @author xvpow
 */
public class Ch7_3 {

    public static void main(String[] args) {
       //寫一個學生(Student)的類
       //學生屬性有三個
       //1 String name 
       //2 int id 
       // 3 int[] scores
       
       //1 擁有建構子 可傳入 name 與 id
       //2 設定name 可檢查　name不可為 null 或長度大於10 
       //3 設定id 可檢查　id 必須大於0
       //4 寫一個Append方法加入成績
       //5 加入成績數量不可大於3
       //6 一個方法可計算出總成績　
       //7 一個方法可計算出成績平均值
       
       //8 成績 可輸入無限筆　使用陣列完成
        
        Student st1 = new Student("Ken",10);
        st1.append(78);
        st1.append(95);
        st1.append(21);
       System.out.printf("sum:%d avg:%.2f %n",st1.sum(),st1.avg());   
    }
    
}
