/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20191022;

/**
 *
 * @author xvpow
 */
public class Test1 {
    Test1(){
        this("V3");
        System.out.println("Test1()");
    }
    
    Test1(String s1,String s2){
      System.out.println("Test1(String s1,String s2)");    
    }
    
    Test1(String s1){
        this("V1","V2");
        System.out.println("Test1(String s1):"+s1);     
    }
    
    
}
