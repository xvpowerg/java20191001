/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20191022;

/**
 *
 * @author xvpow
 */
public class Student {
    private String name;
    private int id;
    private int[] scores = new int[3];
    private int index = 0;
    public Student(String name,int id){
        this.name = name;
        this.id = id;
    }
    public void setName(String name){
        if (name == null || name.length() > 10){
            System.out.println("錯誤的姓名:");
            return;
        }
        this.name = name;
    }
    public void setId(int id){
        if (id < 0){
            System.out.println("錯誤的Id:"+id);
            return;
        }
        this.id = id;
    }
    public void append(int score){
        if (index >= 3){
            System.out.println("成績筆數已滿！");
            return;
        }
        scores[index++] = score;
    }
    
    public int sum(){
        int sum =0;
        for (int s : scores){
            sum += s;
        }
        return sum;
    }
    
   public float avg(){
        float avg = (float)this.sum()/ scores.length;
        return avg;
   }
}
