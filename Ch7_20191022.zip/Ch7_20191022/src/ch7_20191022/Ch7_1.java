/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20191022;
public class Ch7_1 {
    public static void main(String[] args) {
     //類別 
      //以下稱為屬性
      //比例:
      //角色:
      //材質:
      
      
     //物件
      //比例:1比1
      //角色:炭志郎
      //材質:樹酯
      
      Figture f1 = new Figture();
      f1.setId(1);
      f1.scale = "1比1";
      f1.setCharacter("炭志郎");
      f1.material = "樹酯";            
      //比例:4:3:2
      //角色:禰豆子
     //材質:塑膠
     Figture f2 = new Figture();
     f2.setId(2) ;
     f2.scale = "4:3:2";
     f2.setCharacter("禰豆子");
     f2.material = "塑膠";
     
     f1.print();
     f2.print();
     /*System.out.printf("id:%d scale:%s character:%s material:%s %n",  
             f2.id ,
             f2.scale,
             f2.character, 
             f2.material);*/
     
    }
    
}
