/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20191015;
/**
 *
 * @author xvpow
 */
public class Ch5_4 {

    public static void main(String[] args) {
      
        //封箱
        //基本型態型封箱原因
        //1 安全
        //2 規定
        //整數 
           /*
           byte   Byte
           short  Short
           int  Integer
           long Long
        */
        //浮點數 
            /*
            float  Float
            double Double
        */
        //字元 
            //char  Character
        //布林
           //boolean  Boolean
        //Boxing 封箱
        Integer intBoxing = Integer.valueOf(53);
        System.out.println(intBoxing);        
        Float f1 =  Float.valueOf(15.62f);
        System.out.println(f1);
        
        //unboxing 開箱
        int intUnboxing = intBoxing.intValue();
        System.out.println(intUnboxing);
        double fUnboxing =  f1.doubleValue();
        System.out.printf("%.2f",fUnboxing);        
        
    }
    
}
