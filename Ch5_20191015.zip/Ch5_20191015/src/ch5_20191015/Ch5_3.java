/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20191015;

/**
 *
 * @author xvpow
 */
public class Ch5_3 {

    //寫一個方法  假設 format(String name1,String name2)
    //假設我呼叫fomat("Ken","Vivin");
    //回傳:以下格式的字串 員工姓名:Ken,Vivin
    
    
    //n個員工
    //某可參數有N個時 請用Vargs
    //Vargs 特性只能放在參數區域的最後一個
    
    static void test1(String name1,String... names){
        System.out.printf("name1:%s %n",name1);
        for (String n :names){
            System.out.printf("names:%s %n",n);
        }
        
    }
    
    //可傳n各參數 或不傳參數
    //不傳參數回傳0 有傳參數就回傳總和
    static int sum(int...numbers){
        int sum =0;        
        for (int n : numbers){
            sum += n;
        }
        return sum;        
    }
    
    static String format(String... names){
         String msg = "員工姓名:";
            for (String v : names){
                msg += v+" ";
            }      
        return msg;
    }
    public static void main(String[] args) {
       System.out.println(format("Ken","Vivin"));
        System.out.println(format("Ken","Vivin"));
         System.out.println(format("Ken","Vivin"));
          System.out.println(format("Ken","Vivin"));
          
          test1("A1","B1","C1");
          
          System.out.println(sum());
           System.out.println(sum(5,1,8,7));
    }
    
}
