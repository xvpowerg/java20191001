/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20191015;
import java.util.ArrayList;
import java.util.TreeSet;
/**
 *
 * @author xvpow
 */
public class Ch5_1 {
    //方法的位置 必須在類別之下 方法之外
    //方法必要條件 
    // 回傳值 方法名稱 傳入參數 方法本體
    //回傳值 可填入類型(基本型態 或是 參考型態) 或 void 表示無回傳
    //方法名稱 只要符合java變數命名規則
    //傳入參數 可填入類型(基本型態 或是 參考型態)  或 空白
    //方法本體 方法的要執行的內容
   static void test1(){
        System.out.println("test1!!");
        test2();
         System.out.println("test1!! End");
    }
   static void test2(){
       System.out.println("test2!!");      
   }
   
   static int pluse(int a,int b){
       int ans = a + b;
       //return 兩個含意 
       //1把數值 丟出方法 讓方法外的程式碼可以接收
       //2 離開方法
       return ans;
   }   
    
    //static 的方法 只能呼叫static 方法或屬性
    public static void main(String[] args) {        
        test1();
       System.out.println(pluse(5,2));
       int myAns = pluse(5,6);
       System.out.println(myAns);
    }
    
}
