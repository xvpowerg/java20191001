/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20191015;
import java.util.Arrays;

/**
 *
 * @author xvpow
 */
public class Ch5_2 {

    static void  swap(int a,int b){
        int tmp= a;
        a = b;
        b = tmp;
          System.out.printf("swap a:%d b:%d %n",a,b);
    }
    static void swap(int[] array){
        int tmp = array[0];
        array[0] = array[1];
        array[1] = tmp;
    }
    public static void main(String[] args) {
        //考試會考
        //class by value
        int a = 10;
        int b = 20;         
        System.out.printf("a:%d b:%d %n",a,b);
        swap(a,b);
        System.out.printf("a:%d b:%d %n",a,b);
        //call by reference
        //非基本型態 參考類型 (reference)
        int[] array = {71,952};      
        System.out.printf("[0]:%d [1]:%d %n",array[0],array[1]);
         swap(array);
        System.out.printf("[0]:%d [1]:%d %n",array[0],array[1]);
    }
    
}
