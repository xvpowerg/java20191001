/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20191015;

/**
 *
 * @author xvpow
 */
public class Ch5_5 {

    public static void main(String[] args) {
       //字串轉整數
       String input1 = "10";
       String input2 = "21";
       int v1 = Integer.parseInt(input1);
       int v2 = Integer.parseInt(input2);
       System.out.println(v1 + v2);
       
       String input3 = "  1  0    ";
       String input4 = " 21 ";
       //trim() 去除前後空格
       //replaceAll 全部取代
     input3 = input3.replaceAll(" ", "");
     int v3 =   Integer.parseInt(input3);
     int v4 =   Integer.parseInt(input4.trim());
     System.out.println(v3 + v4);
       
     
    }
    
}
