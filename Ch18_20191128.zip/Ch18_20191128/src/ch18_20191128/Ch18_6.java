/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch18_20191128;
import java.util.TreeMap;
public class Ch18_6 {
  public static void main(String[] args) {
        TreeMap <Integer,String> tMap = new TreeMap<>();
        tMap.put(9,"Iris");
        tMap.put(7,"Lindy");
        tMap.put(2,"Tina");
        tMap.put(5,"Ben");        
        tMap.forEach((k,v)->System.out.println(k+":"+v));        
    }
    
}
