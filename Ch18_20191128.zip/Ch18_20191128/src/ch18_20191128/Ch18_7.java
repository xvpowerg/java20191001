/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch18_20191128;
import java.util.ArrayList;
import java.util.TreeMap;
public class Ch18_7 {

    public static void main(String[] args) {
       Item i1=  new Item(10);
       Item i2=  new Item(5);
        Item i3=  new Item(1);
        Item i4=  new Item(7);
        ArrayList<Item> list = new ArrayList<>();
        list.add(i1);
        list.add(i2);
        list.add(i3);
        list.add(i4);
        
       TreeMap<Item,Integer> map = new TreeMap<>(
               (ti1,ti2)->ti1.getId() - ti2.getId());
       for (int i = 0; i<list.size() ;i++){
           map.put(list.get(i), i);
       }
        System.out.println(map);
       
    }
    
}
