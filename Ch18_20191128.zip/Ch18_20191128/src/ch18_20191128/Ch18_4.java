/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch18_20191128;

import java.util.HashMap;
import java.util.ArrayList;

/**
 *
 * @author xvpow
 */
public class Ch18_4 {

    public static void main(String[] args) {
     
       ArrayList<Product> list = new ArrayList();
          Product p1 = new Product("Ken",93);
          Product p2 = new Product("Vivin",50); 
          Product p3 = new Product("Ken",72);   
          Product p4 = new Product("Vivin",83);       
         Product p5 = new Product("Ken",21);   
          Product p6 = new Product("Vivin",54);  
       list.add(p1);
       list.add(p2);
       list.add(p3);
       list.add(p4);
       list.add(p5);
       list.add(p6);
        HashMap<String,Integer> groupMap = new HashMap<>();
        
//        for (Product p : list){
//             String key = p.getName();
//            int price = p.getPrice();
//            if (groupMap.containsKey(key)){
//               price =  groupMap.get(key) + price;
//            }   
//           groupMap.put(key, price);
//        }
  list.forEach(p->{
      String key = p.getName();      
      groupMap.computeIfPresent(key, (k,v)->v + p.getPrice());
      groupMap.computeIfAbsent(key, (k)->p.getPrice()); 
  });
  
  
        
        System.out.println(groupMap);
       
        //產生一組Map Key:name Value:Name的數字加總
       
       
        
    }
    
}
