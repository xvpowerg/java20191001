
package ch18_20191128;

import java.util.Scanner;
import java.util.TreeSet;
import java.util.Comparator;
public class Ch18_1 {
    public static void main(String[] args) {
      Product p1 = new Product("Ps4",9000);
      Product p2 = new Product("Switch",5600); 
     Product p3 = new Product("HtcVive",25600);   
     Product p4 = new Product("IPad",25600);       
 
     Scanner scan = new Scanner(System.in);
     System.out.println("1 小到大");
     System.out.println("2 大到小");
     int action = scan.nextInt();
        
     Comparator<Product> cmp = Comparator.<Product,Integer>comparing(Product::getPrice).
             thenComparing(Product::getName);
     
     switch(action){
         case 1: break;
         case 2:
             cmp = cmp.reversed();
             break;
         default:
            assert false : "錯誤的選項action:"+action;
            throw new IllegalArgumentException("錯誤的選項");
     }
     
     TreeSet<Product> set = new TreeSet<>(cmp);
     set.add(p1);
     set.add(p2);
     set.add(p3);
     set.add(p4);
     set.forEach(System.out::println);
           
    }
    
}
