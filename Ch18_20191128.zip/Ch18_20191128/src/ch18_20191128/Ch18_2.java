/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch18_20191128;
import java.util.HashMap;
public class Ch18_2 {

   
    public static void main(String[] args) {
       HashMap<String,Integer> map = new HashMap<>();
        
        map.put("Howard",50);
        map.put("Join",79);
        map.put("Vivin",63);
        
        //Key 存在
//        map.compute("Join", (k,v)->{
//              System.out.printf("compute Key 存在!!:k: %s v: %d%n",k,v);
//            return 98;
//        });
//        System.out.println(map.get("Join"));
//Key存在不會執行
//        map.computeIfAbsent("Vivin", (k)->{
//                    System.out.println("computeIfAbsent");
//                return 12;
//        });
        
//       map.computeIfPresent("Vivin", (k,v)->{
//           System.out.printf("computeIfPresent 存在 : k:%s v:%d %n",k,v);
//            return 82;
//       });



        //Key 不存在
//        map.compute("Iris", (k,v)->{
//              System.out.printf("compute Key 不存在!!:k: %s v: %d%n",k,v);
//            return 98 + v;
//        });
//       System.out.println(map);
//        System.out.println(map.get("Join"));

//Key不存在會執行
//        map.computeIfAbsent("Iris", (k)->{
//                    System.out.println("computeIfAbsent");
//                return 12;
//        });
//  System.out.println(map);   
//Key不存在不會執行
       map.computeIfPresent("Iris", (k,v)->{
           System.out.printf("computeIfPresent 不存在 : k:%s v:%d %n",k,v);
            return 82;
       });

    }
    
}
