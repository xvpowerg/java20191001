/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch18_20191128;
import java.util.TreeSet;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
public class Ch18_3 {
        static HashMap<Integer,List<Product>> map = new HashMap();
        
        private static void groupProduct(Product p){
             List<Product> pList = map.get(5000);             
            if (p.getPrice() >= 20000) pList = map.get(20000);               
            else if(p.getPrice() >=10000) pList = map.get(10000);               
             pList.add(p); 
        }
    public static void main(String[] args) {
       Product p1 = new Product("Ps4",9000);
       Product p2 = new Product("Switch",5600); 
       Product p3 = new Product("HtcVive",26600);   
       Product p4 = new Product("IPad",25600);       
       Product p5 = new Product("Ps4 +Game",12000);
       Product p6 = new Product("iPhone 7",12800);   
       
       TreeSet<Product> set = new TreeSet<>();
       set.add(p1);
       set.add(p2); 
       set.add(p3);
       set.add(p4); 
       set.add(p5); 
       set.add(p6); 
       set.forEach(System.out::println);
       map.put(5000,new ArrayList<Product>());
       map.put(10000,new ArrayList<Product>());
       map.put(20000,new ArrayList<Product>());
       set.forEach(Ch18_3::groupProduct);
       System.out.println(map);
       //value 是一組List
       //請幫我分組 小於  10000 分在一個Map 的 Value
       //請幫我分組 大於  10000且小20000 分在一個Map 的 Value
      //請幫我分組 其他  分在一個Map 的 Value
      
      //Key使用金額 作為值
        
    }
    
}
