/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch18_20191128;
import java.util.HashMap;
public class Ch18_5 {

  
    public static void main(String[] args) {
     Product p1 = new Product("Ps4",9000);
      Product p2 = new Product("Switch",5600); 
     Product p3 = new Product("HtcVive",25600);
     Product p4 = new Product("HtcVive",25600);
     HashMap<Product,String> map = new HashMap<>();
     map.put(p1, "A1");
     map.put(p2, "B2");
     map.put(p3, "C3");
     map.put(p4, "D4");
     System.out.println(map);
     
    }
    
}
