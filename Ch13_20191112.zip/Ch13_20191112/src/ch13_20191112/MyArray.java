/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20191112;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.Collection;
import java.util.function.UnaryOperator;

class AddConsumer implements Consumer<String>{
    private Collection collection;
    UnaryOperator<String> uno;
    AddConsumer(){
        
    }
     AddConsumer(Collection collection){
        this.collection = collection;
    }
    AddConsumer(Collection collection,UnaryOperator<String> uno){
        this(collection);
        this.uno = uno;
    }
    public void accept(String str){
        if (uno != null){
            str = uno.apply(str);
        }
        collection.add(str);
    }
}

public class MyArray {
    private String[] base = new String[1000];
    int index = -1;
    public void add(String value){
        base[++index] = value;
    }
    public String get(int index){
        return base[index];
    }
    public void foreach(Consumer<String> consumer,Predicate<String> pdc){
        for (int i =0;i <= index;i++){
            
            if (pdc == null || pdc.test(get(i))){
               consumer.accept(get(i));  
            }
            //System.out.println(get(i));
        }
    }
    
      public Collection toCollection(Supplier<Collection<String>> supplier){
          return toCollection(supplier,null);
      }
    public Collection toCollection(Supplier<Collection<String>> supplier,
            UnaryOperator<String> uo){
        Collection<String> collection = supplier.get();
    
        
        AddConsumer addConsumer = null;
        if (uo == null){
          addConsumer = new AddConsumer(collection);
        }else{
          addConsumer = new AddConsumer(collection,uo);  
        }
               
        foreach(addConsumer,null);
        return collection;
    }
    
    
}
