/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20191112;

/**
 *
 * @author shihhaochiu
 */
public class Ch13_3 {
      private static class NewDog extends Dog{
          public void bark(){
              System.out.println("喵喵 ");
          }
          
      }
      private static class CompareInteger implements Compare{
          public boolean comp(Object a,Object b){
                if (a ==null || b ==null || 
                    a instanceof Integer == false ||
                    b  instanceof Integer == false   ){
                    return false;
                }
                Integer iA = (Integer )a;
                 Integer iB = (Integer )b;
              return iA > iB;
          }
      }
      
      static boolean AbiggerB(Compare cmp,Object a,Object b){
          return cmp.comp(a, b);
      }
      
      
    
    public static void main(String[] args) {
       Dog dog = new Dog();
       dog.bark();
       
       Dog dog2 = new NewDog();
       dog2.bark();//喵喵!!
       
       //匿名內部類
       // 用來複寫方法
       Dog dog3 = new Dog(){
            public void bark(){
                System.out.println("吱吱叫！");
            }
       };
       dog3.bark();
       
       
     boolean aIsBiggerb = 
             AbiggerB(new CompareInteger(),10,5);
     System.out.println(aIsBiggerb);
    }
    
}
