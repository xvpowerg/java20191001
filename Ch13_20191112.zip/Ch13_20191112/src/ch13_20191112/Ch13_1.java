/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20191112;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;
import java.util.Collection;
import java.util.ArrayList;
import java.util.HashSet;
class MyConsumer implements Consumer<String>{
    public void  accept(String v){
        System.out.println("姓名:"+v);
    }
}

class MyPredicate implements Predicate<String>{
    public boolean test(String str){
                return str.length() > 3;
        }
}

class MyArrayListSupplier implements Supplier<Collection<String>>{
    public Collection<String> get(){
        return new ArrayList<String>();
    }
}

class MytUnaryOperator implements UnaryOperator<String> {
    
        public String apply(String str){
            return str+".";
        }
    
}
class MytUnaryOperator2 implements UnaryOperator<String> {
    
        public String apply(String str){
            return str+"?";
        }
    
}
public class Ch13_1 {

   //我希望透過Consumer 可顯示 姓名:Vivin 
    //姓名:Vivin 
    //過濾條件 姓名長度大於3的可顯示
    
    public static void main(String[] args) {
      MyArray array = new MyArray();
      array.add("Ken");
      array.add("Vivin");
      array.add("Tom");
      array.add("Join");
    //  array.foreach(new MyConsumer(),new MyPredicate());
      
//      Collection collection = array.
//              toCollection(new MyArrayListSupplier());
//      collection.forEach(System.out::println);
      
//      
        Collection collection2 = array.
              toCollection(new MyArrayListSupplier(),
                      new MytUnaryOperator());
      collection2.forEach(System.out::println);
      
      
        Collection collection3 = array.
              toCollection(new MyArrayListSupplier(),
                      new MytUnaryOperator2());
      collection3.forEach(System.out::println);
    }
    
}
