/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20191112;

/**
 *
 * @author shihhaochiu
 */
public class Ch13_2 {
    //內部類
    //讀取權限 全都可用
    
    // 非靜態內部類
    // 靜態內部類
    // 匿名內部類
    
     private class InnerClass{
         private String msg;
         InnerClass(String msg){
             this.msg  = msg;
         }
         
         public String toString(){
             return msg;
         }
     }
     
     static class StaticInnerClass{
         private int number;
         
         public boolean equals(Object obj){
             if (obj == null || obj instanceof StaticInnerClass == false){
                 return false;
             }
             StaticInnerClass s1 = (StaticInnerClass)obj;
            return number == s1.number;
         }
     }
     
     void testClass(){
        InnerClass iclass = new InnerClass("Test1");
        System.out.println(iclass);
     }
     
    public static void main(String[] args) {
        Ch13_2 ch132 = new Ch13_2();
        ch132.testClass();
        
        
        Ch13_2 ch132x = new Ch13_2();
        Ch13_2.InnerClass chInner= ch132x.new InnerClass("newTest1");
        System.out.println(chInner);
        
        StaticInnerClass s1 = new StaticInnerClass();
        StaticInnerClass s2 = new StaticInnerClass();
        s1.number = 20;
        s2.number = 20;
        System.out.println(s1.equals(s2));
        
        
    }
    
}
