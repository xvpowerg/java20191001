/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20191107;

/**
 *
 * @author shihhaochiu
 */
public interface DataBase {
    //預設情況如下
    //public static final int DEF_CON_MAX = 50;
    int DEF_CON_MAX = 2;
    boolean connection();
    boolean close();
    void query(String sql);
    
   public default void  verifyConnection(){
       if (connection()){
          System.out.println("正確的連線");
          close();
       }else{
            System.out.println("失敗的連線");
       }
      
   }
   
   public default void verifyConnectionTrigger(
           DataBaseEvent dbEvent){
       if (connection()){
           dbEvent.event("MySQL連線成功");
            close();
       }else{
           dbEvent.event("MySQL連線失敗");
       }
       
       
   }
}
