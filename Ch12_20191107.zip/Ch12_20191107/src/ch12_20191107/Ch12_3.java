/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20191107;
import java.util.function.Consumer;
import java.util.function.Function;


class MyPrintStyle implements Consumer<String>{
   public void accept(String v){
       System.out.println(v);
   }
}
class MyPrintStyle2 implements Consumer<String>{
   public void accept(String v){
       System.out.printf("name:%s %n",v);
   }
}
class AbsFunction implements Function<Integer,Integer>{
    public Integer apply(Integer v ){
        if (v < 0 ){
            v *= -1;
        }
        return v;
    }
}
public class Ch12_3 {

    public static void loop(MyIterator it,Consumer<String> consumer){
        it.foreach(consumer);
    }
    
    public static int abs(Function<Integer,Integer> fun,int number){
            return fun.apply(number);
    }
    public static void main(String[] args) {
       //FunctionalInterface
       //一個介面當中 抽象的方法只有一個
       //Consumer<String>
          //void accept(String t)
       //Function<T,R> 
         // R	apply(T t)
       //Predicate<T>  
         //boolean	test(T t)
       //Supplier<T>
          //T get();
       //UnaryOperator<T>
        //T  apply(T t)
        Consumer<String> style = new MyPrintStyle2();
        String[] names = {"Ken","Vivin","Lindy","Join"};
        loop(new MyCollector(names),style);
        
        String myNames = "Howard,Iris,Tom,Ben";
         loop(new MyStringCollector(myNames,","),style);
         
        System.out.println(abs(new AbsFunction(),-100));
    }
    
}
