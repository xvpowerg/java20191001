/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20191107;

/**
 *
 * @author shihhaochiu
 */
public interface TestIF1 {
   void method1();
   //static 方法不會不繼承
  static String testMsg(){
      return "TestIF1!!";
  }
   default void defaultMethod(){
       System.out.println("TestIF1!");
   }
}
