/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20191107;

/**
 *
 * @author shihhaochiu
 */
public class MySQL implements DataBase{
    private int connectionCount = 0;
    
    public boolean connection(){
        if (connectionCount < DataBase.DEF_CON_MAX){
             connectionCount++;
            return true;
        }
        return false;
    }
    public boolean close(){
        if (connectionCount > 0){
            connectionCount--;
            return true;
        }
        
        return false;
    }
    public void query(String sql){
        
    }
}
