/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20191107;
import java.util.function.Consumer;
/**
 *
 * @author shihhaochiu
 */
public interface MyIterator {
    String get(int index);
    int size();
    default void foreach(Consumer<String> consumer){
        for (int i = 0; i < size();i++){
           
            String values = get(i);
            if (consumer != null){
                consumer.accept(values);
            }
            
        }
    }
}
