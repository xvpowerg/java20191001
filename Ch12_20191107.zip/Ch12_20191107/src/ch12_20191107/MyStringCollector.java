/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20191107;

/**
 *
 * @author shihhaochiu
 */
public class MyStringCollector implements MyIterator {
    private String[] tmp ;
    public MyStringCollector(String str,String splitMark){
       tmp = str.split(splitMark);
    }
    
    public String get(int i){
        return tmp[i];
    }
    
    public int size(){
        return tmp.length;
    }
}
