/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20191107;

/**
 *
 * @author shihhaochiu
 */
public class Ch12_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       MySQL mysql1 = new MySQL();
       MySQL  mysql2 = new MySQL();
       MySQL  mysql3 = new MySQL();
       System.out.println(mysql1.connection());
       System.out.println(mysql1.connection());
       mysql1.verifyConnection();
       
       System.out.println(mysql2.connection());
       System.out.println(mysql2.connection());
       System.out.println(mysql2.connection());
      mysql2.verifyConnection();
       System.out.println("最大連線數:"+DataBase.DEF_CON_MAX);
       
      mysql1.verifyConnectionTrigger(new MyDBEvent());
       
      
      
    }
    
}
