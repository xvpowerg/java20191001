/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20191107;

// 錯誤解法 TestIF2 繼承 TestIF1
// 於TestIF3複寫defaultMethod 方法
public interface TestIF3  extends TestIF1,TestIF2{
       default void defaultMethod(){
       System.out.println("TestIF3!");
   }
    
    
}
