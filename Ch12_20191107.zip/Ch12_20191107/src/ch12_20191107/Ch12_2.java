/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch12_20191107;

/**
 *
 * @author shihhaochiu
 */
public class Ch12_2 implements TestIF2 {
  public void method1(){
      
  }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Ch12_2 ch12 = new Ch12_2();
       ch12.defaultMethod();
       System.out.println(TestIF2.testMsg());
    }
    
}
