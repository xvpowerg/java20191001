/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch25_20191224;

/**
 *
 * @author xvpow
 */
public class Ch25_1 {
	private static class Test1{
            String name;
		 public synchronized void add(Test1 t1)
		 {   
                     System.out.println("Add....:"+name+":"+Thread.currentThread().getName());
                     t1.showValue();
		 }
		 public synchronized void showValue() {
		   System.out.
			 println("showValue...:"+name+":"+Thread.currentThread().getName());
		 }
	}
    public static void main(String[] args) {
     Test1 t1 = new Test1();
     t1.name = "T1";     
     Test1 t2 = new Test1();  
     t2.name = "T2";
     
     Thread th1 = new  Thread(()-> t1.add(t2), "Thread1");
     Thread th2 = new  Thread(()->t2.add(t1), "Thread2");
     th1.start();
     th2.start();
     
     
    }
    
}
