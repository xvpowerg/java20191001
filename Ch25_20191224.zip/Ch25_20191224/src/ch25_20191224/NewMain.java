/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch25_20191224;
import java.util.ArrayList;
import java.util.List;
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     List<String> list = new ArrayList<>();
   
      list.add("a1");
      list.add("a2");
      list.add("a3");
      list.add("a4");
      list.add("a5");
      list.add("a6");
        
        Thread th1 = new Thread(()->{
            for (int i = 1;i<=10;i++){
                list.add("v:"+i);
            }        
        });
       
        
        th1.start();
     
        for (String v :list){
            System.out.println(v);
        }
    }
    
}
