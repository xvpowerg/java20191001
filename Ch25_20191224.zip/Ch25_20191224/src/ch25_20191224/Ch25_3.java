/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch25_20191224;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CyclicBarrier;
public class Ch25_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        CyclicBarrier cb = new CyclicBarrier(2);
        List<String> list = new CopyOnWriteArrayList<>();
        list.add("a1");
        list.add("a2");
        list.add("a3");
        list.add("a5");
        list.add("a6");
        list.add("a7");
        list.add("a8");
        list.add("a9");
        
        Thread th = new Thread(()->{
            for (int i =1;i<=1000;i++){
                list.add("v:"+i);
            }
            try{
                 cb.await();
            }catch(Exception ex){
                
            }
          
        });
        th.start();
   
        
        Thread th2 = new Thread(()->{
                 try{
                 cb.await();
            }catch(Exception ex){
                
            }
                for (String v: list){
                    System.out.println(v);
                }
        
        });
        th2.start();
       
    }
    
}
