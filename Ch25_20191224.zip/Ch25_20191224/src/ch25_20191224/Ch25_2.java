/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch25_20191224;
import java.util.concurrent.atomic.AtomicInteger;
public class Ch25_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //希望是執行續安全
        AtomicInteger aint5 = new AtomicInteger(5);
        AtomicInteger aint2 = new AtomicInteger(2);
         int v1 =  aint5.addAndGet(aint2.get());
          System.out.println(v1);
         System.out.println(aint5);
         
        AtomicInteger aint1 = new AtomicInteger(1);  
        int v2 =   aint1.incrementAndGet();
        System.out.println(v2);
        
        AtomicInteger aint7 = new AtomicInteger(7);
        int v3 = aint7.getAndSet(250);
        System.out.println(v3);
        System.out.println(aint7);
        
       AtomicInteger aint8 = new AtomicInteger(8);
        //是否跟AtomicInteger 內原本的數值一樣 如果一樣就寫入15
        aint8.compareAndSet(2, 15);
        System.out.println(aint8);
    }
    
}
