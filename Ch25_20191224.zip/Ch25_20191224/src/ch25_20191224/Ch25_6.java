/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch25_20191224;
import java.util.concurrent.RecursiveTask;
import java.util.concurrent.ForkJoinPool;
public class Ch25_6 {

    private static class FinaMaxTask extends RecursiveTask<Integer> {
        static int counter = 0;
        private int threshold;
        private int[] data;
        private int begin;
        private int end;
        FinaMaxTask(int[] data,int begin,int end,int threshold){
                this.data = data;
                 this.begin = begin;
                 this.end = end;
                 this.threshold = threshold;
        }
        public Integer compute() {
                if (end - begin < threshold){
                    int max = Integer.MIN_VALUE;
                    for (int i = begin; i<= end;i++){
                        int n = data[i];
                        if (n > max){
                            max = n;
                        }
                    }
                    return max;
                }
             int mid = (end - begin) / 2 + begin;
             
           FinaMaxTask a1=  
                 new FinaMaxTask(data, begin, mid,threshold);   
           a1.fork();
          FinaMaxTask a2=  
                  new FinaMaxTask(data, mid + 1, end,threshold);  
                   
            return Math.max(a2.compute(), a1.join());
        }
            
  }
    public static void main(String[] args) {
        // TODO code application logic here
        int[] bigData = new int[1024*1024*256];
        java.util.Random rand = new java.util.Random();
        for (int i= 0; i < bigData.length;i++){
            bigData[i] = rand.nextInt();
        }
        
        FinaMaxTask task = new FinaMaxTask(bigData,0,
                bigData.length  -1,bigData.
                        length / 16);
        ForkJoinPool pool = new ForkJoinPool();
       Integer max =  pool.invoke(task);
       System.out.println(max);
    }
    
}
