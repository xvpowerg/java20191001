/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch25_20191224;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.Future;
public class Ch25_4 {

    public static void main(String[] args) {
//      ExecutorService es =  Executors.newCachedThreadPool();
//      
//      for (int i =1;i<=10000;i++){
//           es.execute(()->{
//               System.out.println("Thread:"+Thread.currentThread().getName()
//               );});
//      }

      ExecutorService es2 = Executors.newFixedThreadPool(5);
//       for (int i =1;i<=10000;i++){
//           es2.execute(()->
//                   System.out.println("Thread:"+
//                           Thread.currentThread().getName()));
//       }
Callable<String> myCall= ()->{
     TimeUnit.SECONDS.sleep(3);
    return "myCall....";};
System.out.println("Start......1");
    Future<String> future = es2.submit(myCall);
  System.out.println("Start......2");  
  
  es2.execute(()->{
            try{
               String v1 = future.get();
               System.out.println(v1);
          }catch(Exception ex){
              System.out.println(ex);
          }
  
  });
  

   System.out.println("Start......3"); 

    }
    
}
