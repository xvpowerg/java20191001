/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch17_20191126;

/**
 *
 * @author xvpow
 */
public class Person implements Comparable<Person> {
    private String name;
    private int age;
    private int salary;
    
    public int compareTo(Person p){
        if (age > p.age){
            return 1;
        }else if (age < p.age ){
           return -1; 
        }
        return 0;
    }
    public Person(String name,int age,int salary){
        this.name = name;
        this.age = age;
        this.salary = salary;
    } 
    
    
    public String getName(){
        return name;
    }
    public int getSalary(){
        return salary;
    }
    
    public int getAge(){
        return age;
    }
   
    public String toString(){
        return name+":"+age+":"+salary;
    }
    
}
