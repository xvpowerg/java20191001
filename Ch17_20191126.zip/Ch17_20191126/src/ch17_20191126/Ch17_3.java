
package ch17_20191126;
import java.util.HashMap;
import java.util.Set;
import java.util.Map.Entry;
public class Ch17_3 {
    private static void printMap(String k,Integer v){
        System.out.println(k+":"+v);
    }
    public static void main(String[] args) {
            //Ｍap 群組
            
        HashMap<String,Integer> map = new HashMap<>();
        map.put("Ken", 82);
        map.put("Vivin", 85);
        map.put("Lindy", 63);
        map.put("Iris", 71);
        //key 唯一的 value可以重複
        System.out.println(map.get("Vivin"));
        //key重複時會覆蓋
        map.put("Lindy", 51);
       System.out.println(map.get("Lindy")); 
       
       Set<Entry<String,Integer>> entrySet =  map.entrySet();
       for (Entry en :entrySet){
           System.out.println(en.getKey()+":"+en.getValue());
       }
       
//       map.forEach((k,v)->{
//           System.out.println(k+":"+v);});
        map.forEach(Ch17_3::printMap);
        
        //如果Key不存在我才寫入Map
        if (map.containsKey("Ken") == false){
            map.put("Ken",0);
        }
        System.out.println(map.get("Ken"));
        System.out.println(map.containsValue(71));
        System.out.println(map.containsValue(63));
        
        //java8才可用
        map.putIfAbsent("NaNa", 21);
        System.out.println(map.get("NaNa"));
        map.putIfAbsent("Ken", 0);
       System.out.println(map.get("Ken"));
        
       System.out.println(map.get("Ben"));
       System.out.println(map.getOrDefault("Ben", -1) != -1);
       //如果key存在才合併
       map.merge("Iris", 80, (ov,nv)->ov+nv);
       System.out.println(map.get("Iris"));
       //如果key不存在直接寫入
        map.merge("Lucy", 96, (ov,nv)->ov+nv);
      System.out.println(map.get("Lucy")); 
      
    }
    
}
