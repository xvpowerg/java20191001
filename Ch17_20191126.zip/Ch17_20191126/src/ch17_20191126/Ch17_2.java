/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch17_20191126;

import java.util.TreeSet;
import java.util.Comparator;

/**
 *
 * @author xvpow
 */
public class Ch17_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Comparator<Person> cmp = Comparator.
                <Person,Integer>comparing(Person::getAge).
                thenComparing(Person::getName).
                thenComparing(Person::getSalary).reversed();
        
        TreeSet<Person> set =  new TreeSet<>(cmp); 
        //String name,int age,int salary
        Person p1=  new Person("Ken",20,5000);
        Person p2=  new Person("Vivin",25,6000);
        Person p3=  new Person("Lindy",23,7000);
        Person p4=  new Person("Join",25,4500); 
        Person p5=  new Person("Ken",20,3000);
        
        set.add(p1);
        set.add(p2);
        set.add(p3);
        set.add(p4);
        set.add(p5);
        
        set.forEach(System.out::println);
        
    }
    
}
