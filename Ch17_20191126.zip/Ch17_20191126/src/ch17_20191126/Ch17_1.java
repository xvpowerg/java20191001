/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch17_20191126;
import java.util.TreeSet;
import java.util.Comparator;
public class Ch17_1 {
   private static class MyComparator implements Comparator<Person>{
       public int compare(Person p1,Person p2){
              System.out.println("Comparator...");
           //p1 gt(大於) p2  回傳 正數
           //p1 lt(小於) p2 回傳 負數
           //p1 eq(等於) p2 回傳 零
           if (p1.getAge() > p2.getAge() ){
               return 1;
           }else if(p1.getAge() < p2.getAge()){
               return -1;
           }
           int nameCmp = p1.getName().compareTo(p2.getName());
         
            if (nameCmp == 0){
                  if (p1.getSalary()  > p2.getSalary()){
                      return 1;
                  }else if(p1.getSalary()  <  p2.getSalary()){
                       return -1;
                  }
            }
           return nameCmp;
       }
   }
   
    private static class MyComparator2 implements Comparator<Person>{
        public int compare(Person p1,Person p2){
            
           int cmp =  p1.getAge() - p2.getAge();
          if (cmp == 0){
             cmp =  p1.getName().compareTo(p2.getName());
         }
          if (cmp == 0) {
              cmp = p1.getSalary() - p2.getSalary();
          }  
          return cmp * -1;
        }
        
        
    }
   
    public static void main(String[] args) {
        //小到大 ASC(遞增)排序法
        //1
        //會以Comparator為主
      //  MyComparator mycmp = new MyComparator();
       // TreeSet<Person> set =  new TreeSet<>(mycmp);
//2        
//       Comparator<Person> cmp2 = Comparator.
//               <Person,Integer>comparing((p)->p.getAge()).
//               thenComparing(p->p.getName()).
//               thenComparing(Person::getSalary);
//      TreeSet<Person> set =  new TreeSet<>(cmp2);

    //大到小 DESC (遞減)　排序法
    MyComparator2 desc = new MyComparator2();
    TreeSet<Person> set =  new TreeSet<>(desc); 
        //String name,int age,int salary
        Person p1=  new Person("Ken",20,5000);
        Person p2=  new Person("Vivin",25,6000);
        Person p3=  new Person("Lindy",23,7000);
        Person p4=  new Person("Join",25,4500); 
        Person p5=  new Person("Ken",20,3000);
        
        set.add(p1);
        set.add(p2);
        set.add(p3);
        set.add(p4);
        set.add(p5);
        
        set.forEach(System.out::println);
        
    }
    
}
