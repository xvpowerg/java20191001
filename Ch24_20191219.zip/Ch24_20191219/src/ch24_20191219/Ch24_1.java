/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch24_20191219;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.io.IOException;
import java.util.List;
public class Ch24_1 {

    public static void main(String[] args) {
        Path p1 =  Paths.get("C:\\MyDir\\myFile.txt");
        int count = 0;
        try{
           List<String> values =  Files.readAllLines(p1); 
           values.forEach(System.out::println);
//           for (String v : values){
//               count += v.toCharArray().length;
//           }
//           System.out.println(count);
//           count = values.stream().mapToInt(s->s.length()).sum();
//          System.out.println(count);
         int total =  values.stream().flatMapToInt(s ->s.chars()).sum();
           System.out.println(total);
        }catch(IOException ex){
            System.out.println(ex);
        }
    }
    
}
