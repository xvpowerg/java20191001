/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch24_20191219;

/**
 *
 * @author xvpow
 */
public class Ch24_4 {
       int x;
      
      public  void test1(){
          
          System.out.println("Step1:"+Thread.currentThread().getName());
          synchronized(this){
                   for (int i =1;i<=5;i++){
                    x++;
                    System.out.println(x);
                }
          }

        System.out.println("Step2:"+Thread.currentThread().getName());
      }
        
    public static void main(String[] args) {
       Ch24_4 c24 = new Ch24_4();
       
       Thread t1 = new Thread(){
           public void run(){
                 c24.test1();
           }
       };
     
       Thread t2 = new Thread(()->{
          c24.test1();
       });
        t1.start();
       t2.start();
    }
    
}
