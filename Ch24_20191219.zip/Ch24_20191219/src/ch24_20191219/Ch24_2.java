/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch24_20191219;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.nio.file.PathMatcher;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.util.stream.Stream;
public class Ch24_2 {

    public static void main(String[] args) {
       Path p1 =  Paths.get("C:\\MyDir");
      try{
          
      Stream<Path> st =  Files.list(p1);//等同於Files.walk(p1,1);
       st.forEach(System.out::println);
       //.{txt,zip} 附檔名是txt或zip的
       PathMatcher pm = FileSystems.getDefault().getPathMatcher("glob:**.{txt,zip}");
    //  st.filter(ph->pm.matches(ph)).forEach(System.out::println);
      System.out.println("======================");
      st = Files.walk(p1,3);//預設層級為Integer最大值2147483647
     st.forEach(System.out::println);
      }catch(IOException ex){
          System.out.println(ex);
      }
      //Files.walk(start, options)
        
    }
    
}
