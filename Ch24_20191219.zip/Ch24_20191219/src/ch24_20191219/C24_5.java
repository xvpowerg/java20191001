/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch24_20191219;
   import java.util.concurrent.locks.ReentrantReadWriteLock;
//給多執行敘用的集合
   import java.util.concurrent.CopyOnWriteArrayList;
   import java.util.concurrent.CopyOnWriteArraySet;
   import java.util.concurrent.ConcurrentHashMap;

public class C24_5 {
   private static int x;
   static ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
   //private static Object key = new Object();

   public static class MyCalculator{
   
      public void pluse(){
           //  synchronized(key){
           lock.writeLock().lock();
                   x++;
                   System.out.println("Thread:"+
                  Thread.currentThread().getName()+":"+x);
          lock.writeLock().unlock();
            // }
        
      }
      public int get(){
          lock.readLock().lock();
          int value = x;
          lock.readLock().unlock();
          return value;
      }
   }     
    public static void main(String[] args) {
        MyCalculator  obj1 = new MyCalculator();
        MyCalculator  obj2 = new MyCalculator();
        Thread t1 = new Thread(()->{ 
            for (int i=1;i<=5;i++){
                obj1.pluse();
                System.out.println(obj1.get());
            }
        });
      Thread t2 = new Thread(()->{ 
            for (int i=1;i<=5;i++){
                obj2.pluse();
                System.out.println(obj2.get());
            }
        });
        
      t1.start();
      t2.start();
    }
    
}
