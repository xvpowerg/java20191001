/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20191003;

/**
 *
 * @author xvpow
 */
public class Ch2_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
               
        int speed = 25;
        if (speed >=62 && speed <= 117){
            System.out.println("輕颱");
        }else if(speed >= 118 && speed <= 183){
           System.out.println("中颱");
        }else if(speed > 184){
           System.out.println("強颱");
        }else{
            System.out.println("熱帶低氣壓");
        }
        
        
        
    }
    
}
