/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20191003;

/**
 *
 * @author xvpow
 */
public class Ch2_5 {

    public static void main(String[] args) {
        
        String name = null;      
        //name.equals("Vivin");
//        if (name.equals("Vivin")){
//            System.out.println("業務");
//        }else if(name.equals("Lindy")){
//             System.out.println("顧問");
//        }else if(name.equals("Ken")){
//              System.out.println("經理");
//        }else{
//              System.out.println("錯誤");
//        }
//        
//        
        switch(name){
            case "Vivin":
                System.out.println("業務");
                break;
            case "Ken":
                 System.out.println("經理");
                break;
            case "Lindy":
                 System.out.println("顧問");
                break;
            default:
                System.out.println("錯誤");
                break;
        }
        
        
        
    }
    
}
