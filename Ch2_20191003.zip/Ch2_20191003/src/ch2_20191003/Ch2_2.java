/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20191003;
import java.util.Scanner;
public class Ch2_2 {
    public static void main(String[] args) {
       /*int age = 10;
       //{}拿掉後if只能控制一段命令 愛考
        if(age >= 18){
            System.out.println("成年");
            System.out.println("好棒棒!");
        }else
          System.out.println("未成年");*/
       Scanner scan = new Scanner(System.in);
       System.out.println("請輸入成績");
       int score = scan.nextInt();
       String msg = score >=60  ? "及格" : "不及格";
       System.out.println(msg);
       //假設輸入-10
       //假設每位學生都加10分
       //輸出10分
       //假設輸入50
       //輸出60分
       int newScore = 10 + (score < 0? 0: score);
       System.out.println(newScore);
       
       //大於等於60
//        if (score >= 60){
//            System.out.println("及格");
//        }else{
//            System.out.println("不及格");
//        }
        
       //if else
       //if else if else if else
       //switch case             
        
        
    }
    
}
