/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20191003;

/**
 *
 * @author xvpow
 */
public class Ch2_7 {

    static int step1(){
        System.out.println("Step1");
        return 1;
    }
    static boolean step2(){
        System.out.println("Step2");
        return true;
    }
    static void step3(){
        System.out.println("Step3");
    }
    
    public static void main(String[] args) {
        
        //分三區塊
        //1 宣告或初始化
        //2 條件為true時可進入迴圈
        // 3 累加迴圈次數
//        for (int i = 1  ; i <= 10  ; i++ ) {
//            System.out.println(i);            
//        }

//      for (int i = 1,k = 6  ; i <= 10 && k > 1  ; i++,k-- ) {
//            System.out.println(i+"_"+k);            
//        }
        
       /* for ( int i = step1() ; i<=3 && step2()  ; step3(),i++ ){
            System.out.println("value:"+i);
        }*/
       
       for (int i =1;i<=5;i++){           
           if (i == 3){               
               //break;//離開迴圈
               continue;//繼續下次迴圈
           }
           System.out.println(i);
           
       }
      
        
    }
    
}
