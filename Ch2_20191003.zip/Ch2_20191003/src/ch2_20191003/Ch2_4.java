/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20191003;

/**
 *
 * @author xvpow
 */
public class Ch2_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       //Switch case 考試重點
       java.util.Scanner scan =
                 new java.util.Scanner(System.in);
       System.out.println("1 跑");
       System.out.println("2 走");
       System.out.println("3 跳");
       int action = scan.nextInt();
       final int RUN = 1;
       final int WALK = 2;
       final int JUMP = 3;
       
       //switch的參數可放置的類型有
       // byte short int char String enum
       //case 條件如果想用變數 必須是 常數
       switch(action){
           case RUN:
               System.out.println("跑"); 
               break;
           case WALK:
               System.out.println("走");
               break;
           case JUMP:
                System.out.println("跳");
               break;
          default:
               System.out.println("錯誤");  
              break;      
       }
       
       
    }
    
}
