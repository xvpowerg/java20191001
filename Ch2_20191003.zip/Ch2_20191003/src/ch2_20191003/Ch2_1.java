/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20191003;

/**
 *
 * @author xvpow
 */
public class Ch2_1 {

    public static void main(String[] args) {
        //關係運算子
        int value1= 31;
        int value2 = 51;
        System.out.println(value1 >value2);
        System.out.println(value1 < value2);
        System.out.println(value1 >= value2);
        System.out.println(value1 <= value2);
        System.out.println(value1 == value2);
        System.out.println(value1 != value2);
     System.out.println("===================");
       String name1 = "Ken";
      //String name2 = "Vivin";
      String name2 = "Ken";
       String name3= new String("Ken");
       System.out.println("name1:"+name1);
       System.out.println("name2:"+name2);
       System.out.println("name3:"+name3);
       System.out.println(name1 == name2);
       System.out.println(name1 == name3);
       //愛考
       //非基本形態請使用equals 比較是否相等
       System.out.println(name1.equals(name3));
       
    }
    
}
