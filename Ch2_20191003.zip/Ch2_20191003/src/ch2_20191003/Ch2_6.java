/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_20191003;

/**
 *
 * @author xvpow
 */
public class Ch2_6 {


    public static void main(String[] args) {
            int v1 = 1__23__45__6;
            int v2 = 1__234____5_____6;
            System.out.println(v1 == v2);
        
            int v3 = 123;
           switch(v3){
               case 1_2___4:
                   break;
               case 14:
                    break;
           }
        
    }
    
}
