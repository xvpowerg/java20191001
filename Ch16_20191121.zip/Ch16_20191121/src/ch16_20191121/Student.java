/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch16_20191121;

/**
 *
 * @author xvpow
 */
public class Student {
    private String name;
    private String city;
    private int score;
    
    public Student(String name,String addr,int score){
        this.name = name;
        this.city = addr;
        this.score = score;
    }
    
    public String getName(){
        return this.name;
    }
   public String getAddr(){
        return this.city;
    }
   public int getScore(){
       return score;
   }
   
   public String toString(){
       return name+":"+city+":"+score;
   }
   
   
   public int hashCode(){
       System.out.println("hashCode:"+ this.name);
    return this.name.hashCode() + this.city.hashCode()+score;
   }
   public boolean equals(Object obj){
       //如果equals成立則hashCode必須相等
       //若p則q的命題
         System.out.println("equals:"+ this.name);
          if (obj == null ||  obj instanceof Student == false){
              return false;
          }
          Student tmpSt = (Student)obj;
          return this.name.equals(tmpSt.name) && 
                  this.city.equals(tmpSt.city) &&
                  this.score == tmpSt.score;
   }
}
