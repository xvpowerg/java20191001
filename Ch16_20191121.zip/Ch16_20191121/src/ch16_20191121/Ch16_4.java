/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch16_20191121;

import java.util.LinkedList;

/**
 *
 * @author xvpow
 */
public class Ch16_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      Item task1 = new Item("task1",10);
      Item task2 = new Item("task2",71);  
      Item task3 = new Item("task3",82);  
      LinkedList<Item> teskList = new LinkedList<>();  
      teskList.add(task1);
      teskList.add(task2);
      teskList.add(task3);
      Item myTask = null;
      while((myTask= teskList.poll())  != null ){
          System.out.println(myTask);
      }
      System.out.println(teskList.size());
     
    }
    
}
