/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch16_20191121;
import java.util.SortedSet;
import java.util.TreeSet;
public class Ch16_7 {
    public static void main(String[] args) {
        TreeSet<Integer> treeSet = new TreeSet<>();
        treeSet.add(5);
        treeSet.add(7);
        treeSet.add(1); 
        treeSet.add(3); 
        treeSet.add(2); 
        treeSet.forEach(System.out::println);
        System.out.println("================");
        
      System.out.println(treeSet.floor(6));//<=6
      System.out.println(treeSet.lower(6));//< 6
      System.out.println(treeSet.floor(1));//<=1
      System.out.println(treeSet.lower(1));//< 1
        
        
     System.out.println(treeSet.ceiling(6));//>=6
      System.out.println(treeSet.higher(6));//>6
      System.out.println(treeSet.ceiling(7));//>=7
      System.out.println(treeSet.higher(7));//>7
      
    SortedSet<Integer>  sortedSet =  treeSet.subSet(0, 6);
    System.out.println(sortedSet);
    
    
    System.out.println("last:"+treeSet.first());
    System.out.println("max:"+treeSet.last());
    
    
        
        
    }
    
}
