/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch16_20191121;
import java.util.LinkedList;
/**
 *
 * @author xvpow
 */
public class Ch16_2 {
    public static void main(String[] args) {
      Item i1 = new Item("Item1",10);
      Item i2 = new Item("Item2",71);  
      Item i3 = new Item("Item3",82);  
      Item i4 = new Item("Item4",93); 
      LinkedList<Item> list = new LinkedList<>();
      list.add(i1);
      list.add(i2);
      list.add(i3);
      list.add(i4);
      list.forEach(System.out::println);
    }
    
}
