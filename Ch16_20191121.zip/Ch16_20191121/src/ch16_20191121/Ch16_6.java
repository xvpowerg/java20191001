/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch16_20191121;
import java.util.HashSet;
import java.util.LinkedHashSet;
public class Ch16_6 {

    public static void main(String[] args) {
        //HashSet<Student> set = new HashSet<>();
        HashSet<Student> set = new LinkedHashSet<>();
        //String name,String city,int score
        Student st1 = new Student("Ken","台中市",95);
        Student st2 = new Student("Iris","台北市",71);
        Student st3 = new Student("Vivin","高雄市",83);
        Student st4 = new Student("Join","台南市",64);
        Student st5 = new Student("Iris","台北市",71);
       // System.out.println(st5.equals(st2));
        set.add(st1);
        set.add(st2);
        set.add(st3);
        set.add(st4);
        set.add(st5);
        set.forEach(System.out::println);
    }
    
}
