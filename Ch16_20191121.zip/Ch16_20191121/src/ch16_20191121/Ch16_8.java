/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch16_20191121;
import java.util.TreeSet;
/**
 *
 * @author xvpow
 */
public class Ch16_8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        TreeSet<Item> set = new TreeSet<>();
      Item i1 = new Item("Item1",10);
      Item i2 = new Item("Item2",71);  
      Item i3 = new Item("Item3",82);  
      Item i4 = new Item("Item4",93); 
      Item i5 = new Item("Item5",62); 
        set.add(i1);
        set.add(i2);
        set.add(i3);
        set.add(i4);
        set.add(i5);
        set.forEach(System.out::println);
        
    }
    
}
