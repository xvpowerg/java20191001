/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch16_20191121;

import java.util.LinkedList;

/**
 *
 * @author xvpow
 */
public class Ch16_3 {

    
    
    
    public static void main(String[] args) {
      Item i1 = new Item("Item1",10);
      Item i2 = new Item("Item2",71);  
      Item i3 = new Item("Item3",82);  
      Item i4 = new Item("Item4",93); 
      Item i5 = new Item("Item5",62); 
       LinkedList<Item> empList = new LinkedList<>();
      LinkedList<Item> list = new LinkedList<>();
      list.add(i1);
      list.add(i2);
      list.add(i3);
      list.add(i4);
      list.offer(i5);
      
      Item r1 =  list.remove();
      System.out.println(r1);
      Item po11= list.poll();
      System.out.println(po11);      
      //empList.remove();//空白的list使用remove會拋出例外
      Item po112 =  empList.poll();
      System.out.println("po112:"+po112);
      System.out.println("=============");
      
        Item peek =  list.peek();//取值不刪除
         System.out.println("peek:"+peek);
       
      list.forEach(System.out::println);
      
      
    }
    
}
