/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch16_20191121;
import java.util.HashSet;
import java.util.Iterator;
public class Ch16_5 {


    public static void main(String[] args) {
        //Set 不可重複
        //HashSet 無順序
        HashSet<Integer> mySet = new HashSet<>();
        mySet.add(10);
        mySet.add(5);
        mySet.add(2);
        mySet.add(9);
        mySet.add(5);
      Iterator<Integer> it = mySet.iterator();
      while(it.hasNext()){
          System.out.println(it.next());
      }
       
        //Set
        //HashSet
        //LinkedHashSet
        //TreeSet
        
    }
    
}
