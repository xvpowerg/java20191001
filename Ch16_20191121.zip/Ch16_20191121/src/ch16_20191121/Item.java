/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch16_20191121;

public class Item implements Comparable<Item> {
    private String name;
    private int price;
    public Item(String name,int price){
        this.name = name;
        this.price = price;
    }
    
    public int compareTo(Item it){
        //如果目前大於 傳入回傳正數
        //如果目前小於 傳入回傳負數
        //如果目前等於 傳入回傳0
        if (price > it.price){
            return 1;
        }else if (price < it.price){
             return -1;
        }
         return 0;
    }
    public String getName(){
        return name;
    }
    public int getPrice(){
        return price;
    }
    
    public String toString(){
        return this.getName()+":"+this.getPrice();
    }
    
    
    public boolean equals(Object obj){
        if (obj == null || obj instanceof Item == false){
            return false;
        }
        Item tmpI = (Item)obj;
        return this.getName().equals(tmpI.getName()) &&
                this.getPrice() == tmpI.getPrice();
    }
}
