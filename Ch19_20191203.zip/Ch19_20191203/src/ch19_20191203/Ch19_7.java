/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch19_20191203;
import java.util.ArrayList;
import java.util.stream.Stream;
/**
 *
 * @author xvpow
 */
public class Ch19_7 {
    public static void main(String[] args) {
      ArrayList<Integer> list = new ArrayList<>();
        list.add(80);
        list.add(70);
        list.add(60);
        list.add(41);
        list.add(53);    
       boolean b1 =  list.stream().allMatch(s->s >= 60);
       System.out.println(b1);
       
       boolean b2 = list.stream().anyMatch(s->s < 60);
       System.out.println(b2);
       
         boolean b3 = list.stream().noneMatch((s)->s < 10);
         System.out.println(b3);
        boolean b4 = list.stream().noneMatch((s)->s > 60);        
         System.out.println(b4);
         
//        boolean b5 = list.stream().peek(System.out::println).allMatch(s->s > 70);
//        System.out.println(b5);
          boolean b6 =  list.stream().peek(System.out::println).anyMatch(s->s <60);
         System.out.println(b6);
    }
    
}
