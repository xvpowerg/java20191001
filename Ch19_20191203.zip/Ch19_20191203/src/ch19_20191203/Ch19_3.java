/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch19_20191203;
import java.util.ArrayList;
public class Ch19_3 {
   public static void method0(ArrayList<Object> t1){
        System.out.println("method0");
    }
    public static void method1(ArrayList<Test2> t1){
        System.out.println("method1");
    }
       public static void method1( Test2 t2){
        System.out.println("method1");
    }
     public static void method2( ArrayList<? extends Test2> t2){
        System.out.println("method1");
        //? extends 不可增加內容
        //只可輪巡
        //t2.add(new Test2());
        
        for (Test2 v : t2){
            
        }
        
    }
     // Test2 自己或副類型的泛型可放入此參數
     public static void method3( ArrayList<? super Test2> t2){
         //? super Test2 
         //可add 也可 輪巡 只是輪巡出的是Object
        System.out.println("method3");
        t2.add(new Test2());
        
        for (Object v : t2){
            
        }
    }
     
    public static void main(String[] args) {
      //多形
        method1( new Test3());
        ArrayList<Test3> list = new ArrayList<>();
        // method1(list);
      //  method0(list);//list 無法傳入
       ArrayList list2 = new ArrayList<>();
       method0(list2);
        method1(list2);
        //=======ArrayList<? extends Test2> 
        method2(list);
        
       ArrayList<Test1> list3 = new ArrayList<>();
        ArrayList<Test3> list4 = new ArrayList<>();
      // method2(list3); // 不可傳入因為Test1不是Test2子類型
      
      method3(list3);
     //method3(list4); 
    }
    
}
