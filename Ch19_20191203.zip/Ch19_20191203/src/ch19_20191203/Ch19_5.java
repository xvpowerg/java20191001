/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch19_20191203;
import java.util.stream.Stream;
import java.util.stream.IntStream;
import java.util.ArrayList;
/**
 *
 * @author xvpow
 */
public class Ch19_5 {

    public static void main(String[] args) {
        
//        Stream<String> str = Stream.of("A1","A2","A3");
//        str.forEach(System.out::println);

//            String[] array = {"N1","N2","N3","N4"};
//            Stream str2 =  Stream.of(array);
//            str2.forEach(System.out::println);
             ArrayList<String> list = new ArrayList<>();
             list.add("V1");
             list.add("V2");
             list.add("V3");
          Stream str3 =  Stream.of(list);
          //str3.forEach(System.out::println);
          
          
//         Stream<Integer> str4=
//        Stream.generate(()->new java.util.Random().nextInt());
//          str4.limit(5).forEach(System.out::println);
          
//         Stream str5 = Stream.iterate(1, (v)->v+1);
//         str5.limit(5).forEach(System.out::println);
         
//         IntStream.range(1, 5).forEach(
//                 (v)->System.out.println(v));

        IntStream.rangeClosed(1, 5).forEach(
                 (v)->System.out.println(v));
        
        
        
    }
    
}
