/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch19_20191203;

/**
 *
 * @author xvpow
 */
public class Ch19_4 {
    
      public <R> R testR(R v){
          return v;
      }
    public static void main(String[] args) {
      Ch19_4 c194 = new  Ch19_4();
     int v =  c194.testR(20);
    double d1 =  c194.testR(325.6);
    System.out.println(d1);
    String v3 =  c194.<String>testR("Ken");
    System.out.println(v3);
    }
    
}
