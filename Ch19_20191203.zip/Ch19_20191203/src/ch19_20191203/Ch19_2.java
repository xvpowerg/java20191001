/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch19_20191203;
import java.util.Map;
import java.util.HashMap;
public class Ch19_2 {

  
    public static void main(String[] args) {
       Student<Integer,Map<String,Integer>> st1 = new Student();
       Map<String,Integer> scoreMap = new HashMap<>();
       st1.setScoreMap(scoreMap);
       st1.putScore("國文", 95);
       st1.putScore("數學", 72);
       st1.putScore("地理", 84);
       System.out.println(st1.getScore("數學"));
       
    }
    
}
