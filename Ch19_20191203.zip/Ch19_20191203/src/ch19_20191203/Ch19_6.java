/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch19_20191203;

import java.util.stream.Stream;
import java.util.ArrayList;
public class Ch19_6 {
    public static void main(String[] args) {
        //Stream 不可重複使用
        //Stream 方法有惰性(Lazy)與終端(Terminal)
        //Stream不會改變來源
        
//       Stream st1 =  Stream.of("Ken","Vlvin","Lindy");
//       st1.forEach(System.out::println);
//       st1.forEach(System.out::println);
        
        Stream st2=  Stream.of("Ken","Vlvin","Lindy");
//        st2.filter((v)->{
//            System.out.println(v);
//        return true;
//        });

//long count = st2.filter((v)->{
//            System.out.println(v);
//        return true;
//        }).count();
//      System.out.println(count);
      
      ArrayList<String> list = new ArrayList<>();
      list.add("Ken");
      list.add("Vivin");
      list.add("Lindy");
      list.stream().filter((n)->n.length() >3).forEach(System.out::println);
      System.out.println(list.size());
      
      
      
    }
    
}
