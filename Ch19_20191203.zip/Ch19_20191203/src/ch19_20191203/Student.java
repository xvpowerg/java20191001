/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch19_20191203;
import java.util.Map;
/**
 *
 * @author xvpow
 */
public class Student<V extends Number,T extends Map<String,V>> {
    private T scoreMap = null;
    public void setScoreMap(T map){
        scoreMap = map;
    }
    public void putScore(String className,V score){
        scoreMap.put(className, score);
    }
    public V getScore(String className){
       return  scoreMap.get(className);
    }
    
}
