/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch19_20191203;

/**
 *
 * @author xvpow
 */
public class Ch19_1 {

    public static void main(String[] args) {
     MyArrayList<Integer> myList = new MyArrayList<>();
        myList.add(10);
        myList.add(95);
        myList.add(38);
        myList.foreach(System.out::println);
    }
    
}
