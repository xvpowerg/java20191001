/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch19_20191203;
import java.util.ArrayList;
import java.util.function.Consumer;
public class MyArrayList<T> {
    private ArrayList<T> baseList = new ArrayList<>();
    public void add(T v){
        baseList.add(v);
    }
    public T get(int index){
        return baseList.get(index);
    }
    public int size(){
        return baseList.size();
    }
    public void foreach(Consumer<T> consumer){
        baseList.forEach(consumer);
    }
    
}
